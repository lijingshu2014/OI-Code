#include<bits/stdc++.h>
using namespace std;
const int maxn=1000007;
const int b=31;
const int mod=1e9+9;
char s[maxn];
int q;
int n;
long long pb[maxn],sum[maxn];
void pre()
{
    for(int i=pb[0]=1;i<=n;i++)
    {
        pb[i]=pb[i-1]*b%mod;
        sum[i]=(sum[i-1]*b+s[i]-'a')%mod;
    }
    return ;
}
long long hashval(int l,int r)
{
    return (sum[r]+mod-sum[l-1]*pb[r-l+1]%mod)%mod;
}
int main()
{
    scanf("%s",s+1);
    n=strlen(s+1);
    scanf("%d",&q);
    pre();
    while(q--)
    {
        int l1,r1,l2,r2;
        scanf("%d%d%d%d",&l1,&r1,&l2,&r2);
        if(r1-l1!=r2-l2) puts("No");
        else if(hashval(l1,r1)==hashval(l2,r2))
            puts("Yes");
        else puts("No");
    }
    return 0;
}