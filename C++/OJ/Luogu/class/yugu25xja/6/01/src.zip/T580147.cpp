#include<bits/stdc++.h>
using namespace std;
const int maxn=200007;
long long a[maxn],b[maxn];
long long tmpa[maxn],tmpb[maxn];
int n;
long long ans;
void solve(int l,int r)
{
    if(l==r) return ;
    int mid=(l+r)/2;
    solve(l,mid);solve(mid+1,r);

    //[l,mid] 已经按照a[i]排好序了
    int cnt1=l,cnt2=mid+1;
    for(int i=mid+1;i<=r;i++)//枚举右半部分的每个雷达站
    {
        int p1=lower_bound(a+l,a+mid+1,a[i]-b[i])-a;//能扫描到的第一个雷达站 第一个>=a[i]-b[i]
        int p2=upper_bound(a+l,a+mid+1,a[i]+b[i])-a-1;//能扫描到的最后一个雷达站 最后一个<=a[i]+b[i]
        //扫描到的范围是 [p1,p2]
        //i与[p1,p2]关联
        ans+=p2-p1+1;
        //范围内如果没有雷达站 p2=p1-1 p2-p1+1=0
    }
    for(int i=l;i<=r;i++)//按照a[i]归并排序
    {
        if(cnt1>mid||cnt2<=r&&a[cnt2]<a[cnt1])
        {
            tmpa[i]=a[cnt2];
            tmpb[i]=b[cnt2];
            ++cnt2;
        }
        else
        {
            tmpa[i]=a[cnt1];
            tmpb[i]=b[cnt1];
            ++cnt1;
        }
    }
    for(int i=l;i<=r;i++)
        a[i]=tmpa[i],b[i]=tmpb[i];
    return ;
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%lld",&a[i]);
    for(int i=1;i<=n;i++)
        scanf("%lld",&b[i]);
    solve(1,n);
    printf("%lld\n",ans);
    return 0;
}