#include<bits/stdc++.h>
using namespace std;
const int maxn=5007;
int a[maxn];
int n;
int solve(int l,int r)
{
    if(l>r) return 0;
    if(l==r) return min(a[l],1);
    int mn=1e9;
    for(int i=l;i<=r;i++)
        mn=min(mn,a[i]);
    for(int i=l;i<=r;i++)
        a[i]-=mn;
    int sum=mn;//总次数
    int lst=l-1;//上一个为0的位置
    for(int i=l;i<=r;i++)
    if(a[i]==0)
    {
        //lst _ _ _ _ _ i
        sum+=solve(lst+1,i-1);
        //特殊情况
        //lst i
        lst=i;
    }
    sum+=solve(lst+1,r);
    return min(sum,r-l+1);
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    printf("%d\n",solve(1,n));
    return 0;
}