#include<bits/stdc++.h>
using namespace std;
const int maxn=(1<<20)+7;
string s;
int n;
map<string,int> mp;
int main()
{
    cin>>s;
    string tmp;
    cin>>n;
    while(n--)
    {
        cin>>tmp;
        sort(tmp.begin(),tmp.end());
        mp[tmp]++;
    }
    int ans=0;
    for(int i=0;i+7<s.length();i++)
    {
        tmp=s.substr(i,8);
        sort(tmp.begin(),tmp.end());
        ans+=mp[tmp];
    }
    cout<<ans<<endl;
    return 0;
}