#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int A[maxn];
int N,K;
int sum[maxn],t[maxn];
//t[i] 表示数字i的出现次数
int main()
{
    scanf("%d%d",&N,&K);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    long long ans=0;
    t[0]++;//t[sum[0]%K]++
    for(int i=1;i<=N;i++)
    {
        sum[i]=(sum[i-1]+A[i])%K;
        //sum[i]%K
        ans+=t[sum[i]];
        //找到之前有多少个与sum[i]相同的sum 就有多少个区间和为K的倍数
        t[sum[i]]++;
    }
    printf("%lld\n",ans);
    return 0;
}