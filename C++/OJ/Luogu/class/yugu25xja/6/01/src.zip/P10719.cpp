#include<bits/stdc++.h>
using namespace std;
const int maxn=107;
char s[maxn][maxn];
int n,m,k;
int sum[maxn][maxn];
int main()
{
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=n;i++)
        scanf("%s",s[i]+1);//从s[i][1]存储字符
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
        {
            sum[i][j]=s[i][j]-'0';
            sum[i][j]+=sum[i-1][j]+sum[i][j-1]-sum[i-1][j-1];
        }
    int ans=1e9;
    for(int a=1;a<=n;a++)
        for(int b=a;b<=n;b++)
            for(int c=1;c<=m;c++)
                for(int d=c;d<=m;d++)
                {
                    if(sum[b][d]+sum[a-1][c-1]-sum[a-1][d]-sum[b][c-1]>=k)
                        ans=min(ans,(b-a+1)*(d-c+1));
                }
    if(ans>n*m) ans=0;
    printf("%d\n",ans);
    return 0;
}