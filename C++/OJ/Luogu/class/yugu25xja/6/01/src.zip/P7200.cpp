#include<bits/stdc++.h>
using namespace std;
long long A,B;
long long ans[10];

bool check(long long x)
{
    if(x<0) x=-x;
    if(x==2) return true;
    if(x==1||x==0) return false;
    for(int i=2;1ll*i*i<=x;i++)
    if(x%i==0) return false;
    return true;
}
bool nxt(int u,long long lst,long long x)
{
    for(int i=1;i<u;i++)
    if(ans[i]==x) return false;
    return check(x)&&check(lst-x);
}
void dfs(int u,long long lst)
{
    if(lst==B)
    {
        printf("%d\n",u-1);
        for(int i=1;i<u;i++)
            printf("%lld%c",ans[i]," \n"[i==u-1]);
        exit(0);
    }
    if(lst==2)
    {
        if(nxt(u,lst,B-2))
        {
            ans[u]=B-2;
            dfs(u+1,B-2);
        }
        else if(nxt(u,lst,B))
        {
            ans[u]=B;
            dfs(u+1,B);
        }
        else if(nxt(u,lst,B+2))
        {
            ans[u]=B+2;
            dfs(u+1,B+2);
        }
    }
    else
    {
        if(nxt(u,lst,lst+2))
        {
            ans[u]=lst+2;
            dfs(u+1,lst+2);
        }
        if(nxt(u,lst,lst-2))
        {
            ans[u]=lst-2;
            dfs(u+1,lst-2);

        }
        if(nxt(u,lst,2))
        {
            ans[u]=2;
            dfs(u+1,2);
        }
    }
    return ;
}
int main()
{
    cin>>A>>B;
    ans[1]=A;
    dfs(2,A);
    puts("-1");
    return 0;
}