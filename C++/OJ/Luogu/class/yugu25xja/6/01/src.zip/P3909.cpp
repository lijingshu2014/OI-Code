#include<bits/stdc++.h>
using namespace std;
const int maxn=1000007;
int A[maxn];
const int mod=1e9+7;
int N;
long long f[maxn],g[maxn];
int main()
{
    scanf("%d",&N);
    for(int i=1;i<=N;i++)
        scanf("%d",&A[i]);
    long long sum=0;
    for(int i=1;i<=N;i++)
    {
        f[i]=(f[i-1]+sum*A[i]%mod)%mod;//sum=[1,i-1]
        sum+=A[i];
        sum%=mod;
    }
    long long ans=0;
    for(int i=1;i<=N;i++)
        ans=(ans+f[i-1]*A[i]%mod)%mod;
    printf("%lld\n",ans*6%mod);
    return 0;
}