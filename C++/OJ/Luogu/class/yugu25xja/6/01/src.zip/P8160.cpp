#include<bits/stdc++.h>
using namespace std;
const int maxn=200007;
struct node{
    int len,num;
}A[maxn];
int n,q;
long long sum[maxn];
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&A[i].len),A[i].num=1;
    for(int i=1;i<=n;i++)
    {
        while(A[i].len%2==0)
        {
            A[i].len>>=1;
            A[i].num<<=1;
        }
        sum[i]=sum[i-1]+A[i].num;
    }
    scanf("%d",&q);
    int pos=1;
    long long x;
    while(q--)
    {
        scanf("%lld",&x);
        while(sum[pos]<x) ++pos;//找到第一个>=x的sum[pos]
        printf("%d\n",A[pos].len);
    }
    return 0;
}