#include<bits/stdc++.h>
using namespace std;
int n,m;
const int maxn=1007;
struct node{
    int h,id;
}a[maxn*maxn];
bool com(const node &x,const node &y)
{
    return x.h<y.h;
}
int book[maxn];//book[i]表示第i个班的同学出现次数
int main()
{
    scanf("%d%d",&n,&m);
    int all=n*m;
    for(int i=1;i<=n;i++)
        for(int j=1;j<=m;j++)
            scanf("%d",&a[(i-1)*m+j].h),a[(i-1)*m+j].id=i;
    sort(a+1,a+1+all,com);
    int cls=0;//班级数量
    int pos=0;//当前R，已加入的同学编号
    int ans=1e9;
    for(int i=1;i<=all;i++)
    {
        while(cls<n&&pos<all)//加入第pos+1个同学
        {
            ++pos;
            if(book[a[pos].id]==0)
                ++cls;
            ++book[a[pos].id];
        }
        if(cls==n) ans=min(ans,a[pos].h-a[i].h);//[i,pos]包括了n个班
        
        --book[a[i].id];
        if(book[a[i].id]==0) --cls;
        //[i+1,pos]内有cls个班级
    }//O(nm log (nm))
    printf("%d\n",ans);
    return 0;
}