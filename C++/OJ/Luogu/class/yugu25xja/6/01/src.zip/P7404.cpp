#include<bits/stdc++.h>
using namespace std;
const int maxn=200007;
int n;
int a[maxn],b[maxn];
long long f[maxn],g[maxn];
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(int i=1;i<=n;i++)
        b[i]=a[i]-a[i-1];
    for(int i=1;i<=n;i++)
    {
        f[i]=f[i-1];
        if(b[i]<1) f[i]+=1-b[i];
    }
    for(int i=n;i>0;i--)
    {
        g[i]=g[i+1];
        if(b[i]>-1) g[i]+=b[i]-(-1);
    }
    long long ans=1e18;
    for(int i=1;i<=n;i++)//[1,i] 变成正的 [i+1,n] 变成负的
        ans=min(ans,max(f[i],g[i+1]));
    printf("%lld\n",ans);
    return 0;
}