#include<bits/stdc++.h>
using namespace std;
const int maxn=47;
int n,l,r;
int w[maxn];
int all;
int ans;
void dfs(int u,int s,int presum)//[1,u-1] 能量值和
{
    if(s>r) return ;
    if(s+all-presum<l) return ;
    if(u>n)
    {
        ++ans;
        return ;
    }
    dfs(u+1,s,presum+w[u]);//不选第u个
    dfs(u+1,s+w[u],presum+w[u]);//选第u个
    return ;
}
int main()
{
    scanf("%d%d%d",&n,&l,&r);
    for(int i=1;i<=n;i++)
        scanf("%d",&w[i]),all+=w[i];
    dfs(1,0,0);
    printf("%d\n",ans);
    return 0;
}