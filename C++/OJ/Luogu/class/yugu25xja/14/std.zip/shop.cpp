#include<bits/stdc++.h>
using namespace std;
const int N = 4005;
const int mod = 1e9+7;
int n,m,k,q,a,b,ans;
int c[N][N];
void getC(){
    for(int i=0;i<=m;i++)c[i][0]=1;
    for(int i=1;i<=m;i++)
        for(int j=1;j<=i;j++)
            c[i][j]=(c[i-1][j]+c[i-1][j-1])%mod;
}
int C(int a,int b){
    if(a<0||b<0) return 1;
    return c[a][b];
}
int main(){
    freopen("shop.in","r",stdin);
    freopen("shop.out","w",stdout);
    cin>>n>>m>>k>>a>>b;
    q=n-k;
    getC();
    if(k==0){
        if(m%b!=0)puts("0");
        else cout<<C(m/b-1,n-1)<<endl;
        return 0;
    }
    else if(k==n){
        if(m%a!=0)puts("0");
        else cout<<C(m/a-1,n-1)<<endl;
        return 0;
    }
    for(int l=k;l*a<=m;l++){
        int r=m-l*a;
        if(r%b!=0)continue;
        r/=b;
        if(r<q)break;
        ans=(ans+1ll*C(l-1,k-1)*C(r-1,q-1)%mod)%mod;
    }
    cout<<ans<<endl;
    return 0;
}