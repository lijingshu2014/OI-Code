#include <bits/stdc++.h>
using namespace std;
const int N = 1e6+5;
int n, ans, a[N];    
int main(){
    freopen("divide.in","r",stdin);
    freopen("divide.out","w",stdout);
    scanf("%d", &n);
    int pre = 0;
    for (int i = 0; i < n; i++){
        int x;
        scanf("%d", &x);
        a[x] = pre;
        pre = x;
    }
    pre = 0;
    for (int i = 0; i < n; i++){
        int x;
        scanf("%d", &x);
        if (i > 0 && a[x] != pre) 
            ans++; 
        pre = x;
    }
    printf("%d\n", ans);
    return 0;
}
