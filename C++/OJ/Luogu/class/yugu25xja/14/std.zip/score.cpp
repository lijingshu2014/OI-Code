#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll sum,plu = 1;
int main(){
    freopen("score.in","r",stdin);
    freopen("score.out","w",stdout);
    cin>>sum;
    for(int i=1;i<=5;i++){
        char ch=getchar();
        while(ch!='+'&&ch!='*')ch=getchar();
        ll x;
        cin>>x;
        if(ch=='+')sum+=x;
        else plu*=x;
    }
    cout<<sum*plu<<"\n";
    return 0;
}