#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int> pii;
const int N = 2e6+5;
int n,m,k,c[N],dis[N];
vector<pii> g[N];
priority_queue<pii,vector<pii>,greater<pii>> q;
bool vis[N];

void dij(){
    memset(dis,0x3f3f,sizeof dis);
    dis[1]=0;
    q.push({dis[1],1});
    while(!q.empty()){
        int u=q.top().second;
        q.pop();
        if(vis[u])continue;
        vis[u]=true;
        for(auto [v,w]:g[u]){
            if(vis[v])continue;
            if(dis[v]>dis[u]+w){
                dis[v]=dis[u]+w;
                q.push({dis[v],v});
            }
        }
    }
}

int main(){
    freopen("metro.in","r",stdin);
    freopen("metro.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    for(int i=1;i<=k;i++)
        scanf("%d",&c[i]);
    for(int i=1;i<=m;i++){
        int u,v,be;
        scanf("%d%d%d",&u,&v,&be);
        g[n+be].push_back({u,0});
        g[n+be].push_back({v,0});
        g[u].push_back({n+be,c[be]});
        g[v].push_back({n+be,c[be]});
    }
    dij();
    printf("%d\n",dis[n]);
    return 0;
}