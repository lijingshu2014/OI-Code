#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 11, tot = 10;
const int M = 1e5 + 5;
const int val[N] = {0, 1, 3, 5, 7, 9, 10, 11, 14, 15, 17};
int n, a[N];
ll ans, f[M], boat[N];
int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= tot; i++)
        scanf("%d", &a[i]);
    // 完全背包预处理出单艘船的最大收益
    for (int i = 1; i <= tot; i++)
        for (int j = i; j <= tot; j++)
            boat[j] = max(boat[j], boat[j - i] + a[i]);
    for (int i = 1; i <= tot; i++)
        boat[i] -= val[i];
    // 用完全背包求出总的最大收益
    for (int i = 1; i <= tot; i++)
        for (int j = i; j <= n; j++)
            f[j] = max(f[j], f[j - i] + boat[i]);
    for (int i = 1; i <= n; i++)
        ans = max(ans, f[i]);
    printf("%lld\n", ans);
    return 0;
}