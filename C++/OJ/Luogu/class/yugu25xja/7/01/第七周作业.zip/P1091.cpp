#include <bits/stdc++.h>
using namespace std;
const int N = 105;
int a[N], b[N], c[N], ans;
int main()
{
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	// 正序
	for (int i = 1; i <= n; i++)
	{
		b[i] = 1;
		for (int j = 1; j <= i - 1; j++)
			if (a[i] > a[j])
				b[i] = max(b[i], b[j] + 1);
	}
	// 逆序
	for (int i = n; i >= 1; i--)
	{
		c[i] = 1;
		for (int j = i + 1; j <= n; j++)
			if (a[j] < a[i])
				c[i] = max(c[i], c[j] + 1);
	}
	for (int i = 1; i <= n; i++)
		ans = max(ans, b[i] + c[i] - 1);
	cout << n - ans << endl;
	return 0;
}