#include <bits/stdc++.h>
using namespace std;
const int N = 41;
const int M = 355;
int n, m, a[M], f[N][N][N], c[5];
int main()
{
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);
	f[0][0][0] = a[1];
	for (int i = 1, x; i <= m; i++)
	{
		scanf("%d", &x);
		c[x]++;
	}
	for (int i1 = 0; i1 <= c[1]; i1++)
		for (int i2 = 0; i2 <= c[2]; i2++)
			for (int i3 = 0; i3 <= c[3]; i3++)
				for (int i4 = 0; i4 <= c[4]; i4++)
				{
					int dis = 1 + i1 + i2 * 2 + i3 * 3 + i4 * 4;
					if (i1 != 0)
						f[i2][i3][i4] = max(f[i2][i3][i4], f[i2][i3][i4] + a[dis]);
					if (i2 != 0)
						f[i2][i3][i4] = max(f[i2][i3][i4], f[i2 - 1][i3][i4] + a[dis]);
					if (i3 != 0)
						f[i2][i3][i4] = max(f[i2][i3][i4], f[i2][i3 - 1][i4] + a[dis]);
					if (i4 != 0)
						f[i2][i3][i4] = max(f[i2][i3][i4], f[i2][i3][i4 - 1] + a[dis]);
				}
	printf("%d\n", f[c[2]][c[3]][c[4]]);
	return 0;
}
