#include <bits/stdc++.h>
using namespace std;
const int N = 365;
const int MOD = 360;

int n, k, q;
int dp[N];
int flag[N];
int rad[10];

int main()
{
	scanf("%d%d", &n, &q);
	for (int i = 0; i < n; ++i)
	{
		scanf("%d", &rad[i]);
		rad[i] %= MOD;
	}

	dp[0] = 1;

	for (int i = 0; i < n; ++i)
	{
		memset(flag, 0, sizeof(flag));
		int j = 0;
		while (!flag[j]) //枚举所有情况
		{ 
			flag[j] = 1;
			j = (j + rad[i]) % MOD; //MOD=360，将角度换算到360内
		}

		for (int j = 0; j < MOD; ++j)
		{
			if (dp[j] == 0)
				continue;
			for (int k = 0; k < MOD; ++k)
			{
				dp[(j + k) % MOD] |= flag[k];
				dp[(j - k + MOD) % MOD] |= flag[k];
			}
		}
	}

	for (int i = 0; i < q; ++i)
	{
		scanf("%d", &k);
		k %= MOD;
		puts(dp[k] ? "YES" : "NO");
	}
	return 0;
}
