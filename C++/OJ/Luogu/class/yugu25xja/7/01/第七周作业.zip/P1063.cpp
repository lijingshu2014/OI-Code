#include <bits/stdc++.h>
using namespace std;
int n, maxx, a[250], f[250][250];
int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &a[i]);
        a[n + i] = a[i];
    }
    for (int j = 2; j <= 2 * n - 1; j++)
        for (int i = j - 1; i > 0 && j - i < n; i--)
            for (int k = i; k < j; k++)
                f[i][j] = max(f[i][j], f[i][k] + f[k + 1][j] + a[i] * a[k + 1] * a[j + 1]);
    for (int i = 1; i <= n; i++)
        maxx = max(maxx, f[i][i + n - 1]);
    printf("%d\n", maxx);
    return 0;
}