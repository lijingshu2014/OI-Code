#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 105;
int n, k;
ll f[N][N][N], a[N][N], ans = -1e18;
int main()
{
	scanf("%d%d", &n, &k);
	k = min(k, n);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= i; j++)
			scanf("%lld", &a[i][j]);
	memset(f, 0xcfcf, sizeof f);
	f[0][0][0] = 0;
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= i; j++)
		{
			for (int l = 0; l <= min(k, i); l++)
			{
				f[i][j][l] = max(f[i - 1][j][l], f[i - 1][j - 1][l]) + a[i][j];
				if (l != 0)
					f[i][j][l] = max(f[i][j][l], max(f[i - 1][j][l - 1], f[i - 1][j - 1][l - 1]) + a[i][j] * 3);
			}
		}
	for (int j = 1; j <= n; j++)
		for (int l = 0; l <= k; l++)
			ans = max(ans, f[n][j][l]);
	printf("%lld\n", ans);
	return 0;
}