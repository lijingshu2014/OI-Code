#include <bits/stdc++.h>
using namespace std;
const int N = 20;
int n, m, a[N][N];
struct node
{
	int val;//最大利润
	string s;//每一位表示每家公司分得机器数
	bool operator<(node b) const
	{
		//自定义比较规则
		return val < b.val || val == b.val && s > b.s;
	}
	node operator+(int num)
	{
		return node{val + num, s};
	}
	node operator+(char t)
	{
		return node{val, s + t};
	}
} f[N][N];
int main()
{
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++)
			scanf("%d", &a[i][j]);
	for (int i = 1; i <= n; i++)
		for (int j = 0; j <= m; j++)
		{
			f[i][j] = f[i - 1][j] + char(0);
			for (int k = 1; k <= j; k++)
				if (f[i][j] < f[i - 1][j - k] + a[i][k] + char(k))
					f[i][j] = f[i - 1][j - k] + a[i][k] + char(k);
		}
	printf("%d\n", f[n][m].val);
	for (int i = 1; i <= n; i++)
		printf("%d %d\n", i, f[n][m].s[i - 1]);
	return 0;
}