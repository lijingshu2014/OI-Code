#include <bits/stdc++.h>
using namespace std;
const int N = 105, M = 1e5 + 5;
const int inf = 1e9;
using namespace std;
int n, ans, sum, num[N], f[N][M];
int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &num[i]);
        sum += num[i];
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = sum; j; j--)
            // 考虑所有情况
            f[i][j] = j == num[i] | f[i - 1][j] | f[i - 1][j + num[i]] | f[i - 1][abs(j - num[i])];
    }
    for (int i = 1; i <= sum; i++)
        ans += f[n][i];
    printf("%d\n", ans);
    return 0;
}