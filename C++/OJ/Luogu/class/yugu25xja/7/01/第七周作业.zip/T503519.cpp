#include <bits/stdc++.h>
using namespace std;
const int N = 1e6 + 5;
const int inf = 1e9;
int n, num[N], f[N];
int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &num[i]);
		if (i <= 2)
		{
			f[i] = 0;
			continue;
		}
		f[i] = f[i - 1] + num[i]; // 第 i 层手动搬运
		if (i - 2 >= 0)
			f[i] = min(f[i], f[i - 2] + num[i - 1]); // 第 i - 1  层手动搬运
		if (i - 3 >= 0)
			f[i] = min(f[i], f[i - 3] + num[i - 2]); // 第 i - 2  层手动搬运
	}
	printf("%d\n", f[n]);
	return 0;
}