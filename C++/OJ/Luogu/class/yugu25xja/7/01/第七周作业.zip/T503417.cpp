#include <bits/stdc++.h>
using namespace std;
long long a, b, c, d;
int main()
{
	cin >> a >> b >> c >> d;
	if (a * c < INT_MIN || a * c > INT_MAX || b * d < INT_MIN || b * d > INT_MAX || a * d < INT_MIN || a * d > INT_MAX || b * c < INT_MIN || b * c > INT_MAX)
	{
		cout << "long long int";
	}
	else
	{
		cout << "int";
	}
	return 0;
}
