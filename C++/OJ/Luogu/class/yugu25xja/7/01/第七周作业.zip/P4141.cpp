#include <bits/stdc++.h>
using namespace std;

const int N = 2005;

int n, m;
int w[N];
int dp[N], ans[N];

int main()
{
    scanf("%d%d", &n, &m);
    for (int i = 1; i <= n; i++)
        scanf("%d", &w[i]);

    dp[0] = 1;
    for (int i = 1; i <= n; i++)
        for (int j = m; j >= w[i]; j--)
            dp[j] = (dp[j] + dp[j - w[i]]) % 10;

    for (int i = 1; i <= n; i++, putchar('\n'))
    {
        for (int j = 0; j <= m; j++)
            ans[j] = dp[j];
        for (int j = w[i]; j <= m; j++)
            ans[j] = (ans[j] - ans[j - w[i]] + 10) % 10;
        for (int j = 1; j <= m; j++)
            putchar(ans[j] + '0');
    }
    return 0;
}