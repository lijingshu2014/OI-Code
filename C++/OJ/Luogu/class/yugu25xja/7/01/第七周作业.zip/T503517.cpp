#include <bits/stdc++.h>
using namespace std;
const int N = 205;
int n, cost[N][N], f[N];
int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n - 1; i++)
		for (int j = i + 1; j <= n; j++)
			scanf("%d", &cost[i][j]);
	for (int i = 2; i <= n; i++)
	{
		f[i] = INT_MAX;
		for (int j = 1; j < i; j++) // 枚举上一个乘坐的车站
			f[i] = min(f[i], f[j] + cost[j][i]);
	}
	printf("%d\n", f[n]);
	return 0;
}