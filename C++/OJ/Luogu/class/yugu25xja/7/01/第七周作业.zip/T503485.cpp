#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
const int inf = 1e9;
int n, num[N], f[N], ans = -inf;
int main()
{
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &num[i]);
		f[i] = num[i] + max(f[i - 1], 0); // DP转移
		ans = max(f[i], ans);
	}
	printf("%d\n", ans);
	return 0;
}