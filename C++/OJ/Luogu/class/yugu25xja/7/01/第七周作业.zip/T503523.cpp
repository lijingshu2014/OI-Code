#include <bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 5;
struct node
{
    int l, r;
} a[maxn];
bool cmp(node x, node y) { return x.l < y.l; }
int n, b[maxn], len;
int main()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i++)
        scanf("%d%d", &a[i].l, &a[i].r);
    sort(a + 1, a + 1 + n, cmp);
    for (int i = 1; i <= n; i++)
    {
        if (a[i].r > b[len])
            b[++len] = a[i].r;
        else
        {
            int pos = lower_bound(b + 1, b + 1 + len, a[i].r) - b;
            b[pos] = a[i].r;
        }
    }
    printf("%d\n", len);
    return 0;
}