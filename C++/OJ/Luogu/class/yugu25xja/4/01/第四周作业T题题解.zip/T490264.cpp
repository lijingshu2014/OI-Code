#include<bits/stdc++.h>
using namespace std;
const int maxn=500007;
const int J=20;
const int lim=2.5e5;
int fa[J+1][maxn];
int dep[maxn];
vector <int> m[maxn];
int n,q,p;
void dfs(int u)
{
    for(int v:m[u])
    {
        if(v==fa[0][u]) continue;
        fa[0][v]=u;
        dep[v]=dep[u]+1;
        dfs(v);
    }
    return ;
}
void pre()
{
    for(int k=1;k<=J;k++)
        for(int i=1;i<=n;i++)
            fa[k][i]=fa[k-1][fa[k-1][i]];
    return ;
}
int query(int x,int d)
{
    d=min(d,dep[x]);
    while(d--)
        x=fa[0][x];
    return x;
}
int main()
{
    scanf("%d%d%d",&n,&q,&p);
    int u,v;
    for(int i=1;i<n;i++)
    {
        scanf("%d%d",&u,&v);
        m[u].push_back(v);
        m[v].push_back(u);
    }
    dfs(1);
    pre();
    while(q--)
    {
        scanf("%d%d",&u,&v);
        if(u==1)
            p=v;
        else
        {
            p=query(p,v);
            printf("%d\n",p);
        }
    }
    return 0;
}