#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
bitset <maxn> A,B;
int n,m;
int main()
{
    scanf("%d%d",&n,&m);
    int x;
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&x);
        A[x]=1;
    }
    for(int i=1;i<=m;i++)
    {
        scanf("%d",&x);
        B[x]=1;
    }
    int ans1=(A&B).count();
    int ans2=(A|B).count();
    int ans3=(A^(A&B)).count();
    printf("%d %d %d\n",ans1,ans2,ans3);
    return 0;
}