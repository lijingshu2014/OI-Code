#include<bits/stdc++.h>
using namespace std;
const int maxn=500007;
int a[maxn],b[maxn],c[maxn<<1];
int n,m;
int main()
{
    scanf("%d%d",&n,&m);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(int i=1;i<=m;i++)
        scanf("%d",&b[i]);
    int p1=1,p2=1;
    long long ans=0;
    for(int i=1;i<=n+m;i++)
    {
        if(p1>n) c[i]=b[p2++];
        else if(p2>m) c[i]=a[p1++];
        else if(a[p1]<=b[p2]) c[i]=a[p1++];
        else
        {
            c[i]=b[p2++];
            ans+=(n-p1+1);
        }
    }
    for(int i=1;i<=n+m;i++)
    {
        printf("%d",c[i]);
        if(i!=n+m) printf(" ");
    }
    printf("\n");
    printf("%lld\n",ans);
    return 0;
}