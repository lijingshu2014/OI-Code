#include<bits/stdc++.h>
using namespace std;
long long len[107];
int N;
char f(int n,int x)
{
    if(n==0)
    {
        if(x==1) return 'm';
        else return 'o';
    }
    //len[n-1]+1+(n+2)+len[n-1]
    if(x>len[n-1]&&x<=len[n-1]+n+3)
    {
        if(x==len[n-1]+1) return 'm';
        else return 'o';
    }
    else if(x<=len[n-1]) return f(n-1,x);
    else return f(n-1,x-(len[n-1]+n+3));
}
int main()
{
    // freopen("1.in","r",stdin);
    len[0]=3;
    for(int i=1;i<=30;i++)
        len[i]=len[i-1]*2+i+3;
    int cnt=0;
    
    scanf("%d",&N);
    for(int i=1;i<=30;i++)
    if(N<=len[i]) {cnt=i;break;}
    cout<<f(cnt,N);
    return 0;
}