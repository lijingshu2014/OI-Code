#include<bits/stdc++.h>
using namespace std;
int n,q,rt;
const int maxn=500007;
const int J=19;
int fa[J+1][maxn];
vector <int> m[maxn];
int dep[maxn];
void dfs(int u)
{
    for(auto v:m[u])
    {
        if(v==fa[0][u]) continue;
        fa[0][v]=u;
        dep[v]=dep[u]+1;
        dfs(v);
    }
    return ;
}
void pre()
{
    for(int k=1;k<=J;k++)
        for(int i=1;i<=n;i++)
        fa[k][i]=fa[k-1][fa[k-1][i]];
    return ;
}
int LCA(int x,int y)
{
    if(dep[x]<dep[y]) swap(x,y);
    int d=dep[x]-dep[y];
    for(int k=0;k<=J;k++)
    if(d&(1<<k)) x=fa[k][x];
    if(x==y) return x;
    for(int k=J;k>=0;k--)
    if(fa[k][x]!=fa[k][y])
    {
        x=fa[k][x];
        y=fa[k][y];
    }
    return fa[0][x];
}
int main()
{
    scanf("%d%d%d",&n,&q,&rt);
    int u,v;
    for(int i=1;i<n;i++)
    {
        scanf("%d%d",&u,&v);
        m[u].push_back(v);
        m[v].push_back(u);
    }
    dfs(rt);
    pre();
    while(q--)
    {
        scanf("%d%d",&u,&v);
        printf("%d\n",LCA(u,v));
    }
    return 0;
}