#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
const int J=17;
int n,q;
int a[maxn];
int fa[J+1][maxn],sum[J+1][maxn];
vector <int> m[maxn];
int dep[maxn];
void dfs(int u)
{
    sum[0][u]=a[u];
    for(auto v:m[u])
    {
        if(v==fa[0][u]) continue;
        dep[v]=dep[u]+1;
        fa[0][v]=u;
        dfs(v);
    }
    return ;
}
void pre()
{
    for(int k=1;k<=J;k++)
        for(int i=1;i<=n;i++)
        {
            fa[k][i]=fa[k-1][fa[k-1][i]];
            sum[k][i]=sum[k-1][i]+sum[k-1][fa[k-1][i]];
        }
    return ; 
}
int query(int x,int y)
{
    if(dep[x]<dep[y]) swap(x,y);
    int d=dep[x]-dep[y];
    int res=0;
    for(int k=0;k<=J;k++)
    {
        if(d&(1<<k))
        {
            res+=sum[k][x];
            x=fa[k][x];
        }
    }
    if(x==y)
    {
        res+=a[x];
        return res;
    }
    for(int k=J;k>=0;k--)
    if(fa[k][x]!=fa[k][y])
    {
        res+=sum[k][x];
        res+=sum[k][y];
        x=fa[k][x];
        y=fa[k][y];
    }
    res+=sum[0][x];
    res+=sum[0][y];
    res+=a[fa[0][x]];
    return res;
}
int main()
{
    scanf("%d%d",&n,&q);
    int u,v;
    for(int i=1;i<n;i++)
    {
        scanf("%d%d",&u,&v);
        m[u].push_back(v);
        m[v].push_back(u);
        a[u]++;a[v]++;
    }
    dfs(1);
    pre();
    while(q--)
    {
        scanf("%d%d",&u,&v);
        printf("%d\n",query(u,v));
    }
    return 0;
}