#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int a[maxn][2];
int opty[37][2];
int n,m;
int main()
{
    scanf("%d%d",&n,&m);
    char s[7];
    for(int i=1;i<=n;i++)
    {
        scanf("%s",s);
        if(s[0]=='A')
            a[i][0]=1;
        else if(s[0]=='O')
            a[i][0]=2;
        else
            a[i][0]=3;
        scanf("%d",&a[i][1]);
    }
    for(int k=0;k<=30;k++)
    {
        for(int j=0;j<2;j++)
        {
            opty[k][j]=j;
            for(int i=1;i<=n;i++)
            {
                if(a[i][0]==1)//AND
                {
                    if(opty[k][j]==0||(a[i][1]&(1<<k))==0)
                        opty[k][j]=0;
                    else opty[k][j]=1;
                }
                else if(a[i][0]==2)//OR
                {
                    if(opty[k][j]==1||(a[i][1]&(1<<k))!=0)
                        opty[k][j]=1;
                    else opty[k][j]=0;
                }
                else
                {
                    if((opty[k][j]==1)!=((a[i][1]&(1<<k))!=0))
                        opty[k][j]=1;
                    else opty[k][j]=0;
                }
            }
        }
    }
    int ans=0,res=0;
    for(int k=30;k>=0;k--)
    {
        if(ans+(1<<k)<=m&&opty[k][0]==0&&opty[k][1]==1)
            ans+=(1<<k),res+=(1<<k);
        else if(opty[k][0]==1)
            res+=(1<<k);
    }
    cout<<res;
    return 0;
}