#include<bits/stdc++.h>
using namespace std;
string f(int n,unsigned long long k)
{
    if(n==1)
    {
        if(k==0) return "0";
        return "1";
    }
    if(k>=(1ull<<(n-1)))//k=(1ull<<(n-1))+tmp 
    {
        return "1"+f(n-1,(1ull<<(n-1))-(k-(1ull<<(n-1)))-1);
    }
    else 
        return "0"+f(n-1,k);
}
int main()
{
    int n;
    unsigned long long k;
    cin>>n>>k;
    cout<<f(n,k)<<endl;
    return 0;
}