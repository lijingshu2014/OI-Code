#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
int a[maxn];
int sum[maxn];
int cnt[37][2];
int n;
long long ans;
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(int k=0;k<=20;k++)
        cnt[k][0]=1;
    for(int i=1;i<=n;i++)
    {
        sum[i]=sum[i-1]^a[i];
        for(int k=0;k<=20;k++)
        {
            if((sum[i]>>k)&1)
                ans+=cnt[k][0]*(1ll<<k),cnt[k][1]++;
            else ans+=cnt[k][1]*(1ll<<k),cnt[k][0]++;
        }
    }
    cout<<ans;
    return 0;
}