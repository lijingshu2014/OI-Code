#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
int n,m,c,k;
const int maxn=1000007;
vector <int> q[77];
vector <int> fd;
bool st[maxn];
int main()
{
    ull all=0,x;
    scanf("%d%d%d%d",&n,&m,&c,&k);
    for(int i=1;i<=n;i++)
    {
        scanf("%llu",&x);
        all|=x;
    }
    int p,qq;
    for(int i=1;i<=m;i++)
    {
        scanf("%d%d",&p,&qq);
        q[p].push_back(qq);
    }
    for(int i=0;i<k;i++)
    if((all>>i)&1)
    {
        for(auto val:q[i])
            fd.push_back(val);
    }
    sort(fd.begin(),fd.end());
    int cnt=0;
    for(int i=0;i<k;i++)
    {
        bool fl=false;
        for(auto val:q[i])
        {
            auto it=lower_bound(fd.begin(),fd.end(),val);
            if(it==fd.end()||(*it)!=val)
                {fl=true;break;}
        }
        if(!fl)
            ++cnt;
    }
    if(n==0&&cnt==64)
        printf("18446744073709551616\n");
    else
    {
        if(cnt==64)
            printf("%llu\n",(1ull<<63)-n+(1ull<<63));
        else
            printf("%llu\n",(1ull<<cnt)-n);
    }
    return 0;
}