#include<bits/stdc++.h>
using namespace std;
const int maxn=100007;
const int J=17;
int nxt[J+1][maxn],mx[J+1][maxn];
int N,Q;
int sum[J+1][maxn];
int R[maxn],C[maxn];
int main()
{
    scanf("%d%d",&N,&Q);
    for(int i=1;i<=N;i++)
        scanf("%d%d",&R[i],&C[i]);
    for(int i=1;i<=N;i++)
        mx[0][i]=R[i];
    // mx[k][i] -> i~i+2^k-1 max
    for(int k=1;k<=J;k++)
        for(int i=1;i+(1<<k)-1<=N;i++)
            mx[k][i]=max(mx[k-1][i],mx[k-1][i+(1<<(k-1))]);
            // i~i+2^k-1 -> i~i+2^(k-1)-1 | i+2^(k-1)~i+2^(k-1)-1
    for(int i=1;i<=N;i++)
    {
        int pos=i+1;//[i,pos-1] <=R[i]
        for(int k=J;k>=0;k--)
        {
            if(pos+(1<<k)-1<=N&&mx[k][pos]<=R[i])
            //[pos,pos+2^k-1] <=R[i]
                pos+=(1<<k);
        }
        nxt[0][i]=pos;
    }
    nxt[0][N+1]=N+1;
    for(int k=1;k<=J;k++)
    {
        nxt[k][N+1]=N+1;
        for(int i=1;i<=N;i++)
            nxt[k][i]=nxt[k-1][nxt[k-1][i]];
    }
for(int i=1;i<=N;i++)
    sum[0][i]=C[i];
for(int k=1;k<=J;k++)
    for(int i=1;i<=N;i++)
        sum[k][i]=sum[k-1][i]+sum[k-1][nxt[k-1][i]];
    while(Q--)
    {
        int r,v;
        scanf("%d%d",&r,&v);
        for(int k=J;k>=0;k--)
        {
            if(nxt[k][r]>N) continue;
            if(sum[k][r]<v)
            {
                v-=sum[k][r];
                r=nxt[k][r];
            }
        }
        if(v<=C[r])
            printf("%d\n",r);
        else printf("%d\n",0);
    }
    return 0;
}