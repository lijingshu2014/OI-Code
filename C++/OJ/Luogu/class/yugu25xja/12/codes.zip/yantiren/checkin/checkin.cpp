#include <bits/stdc++.h>
using namespace std;

#define int long long
#define rep(a, b, c) for (int a = b; a <= c; ++a)
#define inrange(x, l, r) assert((l) <= (x) && (x) <= (r))

void solve() {
    int a, b, p;
    cin >> a >> b >> p;
    inrange(a, 1, 1e6);
    inrange(b, 1, 1e6);
    inrange(p, 1, 1e6);
    vector<int> vis(p + 1, -1);
    assert(a < p && b < p);
    for (int x = 0, cur = 1; ; ++x) {
        if (vis[cur] != -1) break;
        vis[cur] = x;
        cur = (cur * a) % p;
    }
    if (vis[b] == -1) {
        cout << "No Solution\n";
    } else {
        cout << vis[b] << '\n';
    }
}

signed main() {
    freopen("checkin.in", "r", stdin);
    freopen("checkin.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    cin >> t;
    inrange(t, 0, 100);
    while (t--) solve();
}