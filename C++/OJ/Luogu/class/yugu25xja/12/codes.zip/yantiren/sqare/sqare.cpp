#include <bits/stdc++.h>
using namespace std;

#define int long long
#define rep(a, b, c) for (int a = b; a <= c; ++a)
#define inrange(x, l, r) assert((l) <= (x) && (x) <= (r))

int n, m;
int a[105][105];
int f[105][105][105]; 
// f[i][l][r], at level i, walking from l to r, the maximal total expense
int g[105][105];
// g[i][j], at level i - 1, going down 1 level to position j, the maximal expense

void solve() {
    cin >> n >> m;
    inrange(n, 1, 100);
    inrange(m, 1, 100);
    rep(i, 1, n) rep(j, 1, m) {
        cin >> a[i][j];
        inrange(a[i][j], -1e9, 1e9);
    }
    std::fill(f[0][0], f[0][0] + sizeof(f) / sizeof(int), -1e18);
    std::fill(g[0], g[0] + sizeof(g) / sizeof(int), -1e18);
    rep(i, 1, m) g[1][i] = 0;
    rep(i, 1, n) {
        rep(l, 1, m) {
            int pa = 0, pf = -1e18;
            rep(r, l, m) {
                pf = max(pf, g[i][r]);
                pa += a[i][r];
                f[i][l][r] = (pa + pf);
            }
        }
        rep(l, 1, m) rep(r, l, m) {
            rep(x, l, r) {
                g[i + 1][x] = max(g[i + 1][x], f[i][l][r]);
            }
        }
    }

    int ans = -1e18;
    rep(i, 1, m) {
        ans = max(ans, g[n + 1][i]);
    }
    cout << ans << '\n';
}

signed main() {
    freopen("sqare.in", "r", stdin);
    freopen("sqare.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--) solve();
}