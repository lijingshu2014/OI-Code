#include <bits/stdc++.h>
using namespace std;

#define int long long
#define rep(a, b, c) for (int a = b; a <= c; ++a)
#define inrange(x, l, r) assert((l) <= (x) && (x) <= (r))

using pii = pair<int, int>;

int n, k;
int a[100005][15];
int f[100005];
map<int, int> mp[15];
set<pii> s;

void solve() {
    cin >> n >> k;
    inrange(n, 2, 100000);
    inrange(k, 1, 10);
    rep(i, 1, n) {
        rep(j, 1, k) {
            cin >> a[i][j];
            inrange(a[i][j], 1, 1e9);
            mp[j][a[i][j]]++;
        }
    }
    rep(i, 1, n) {
        rep(j, 1, k) {
            f[i] = max(f[i], mp[j][a[i][j]]);
        }
        s.insert({f[i], i});
    }
    rep(d, 1, n) {
        while (s.size() && s.begin()->first < d) {
            auto it = s.begin();
            s.erase(it);
        }
        cout << n - s.size() << ' ';
    }
    cout << '\n';
}

signed main() {
    freopen("paper.in", "r", stdin);
    freopen("paper.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--) solve();
}