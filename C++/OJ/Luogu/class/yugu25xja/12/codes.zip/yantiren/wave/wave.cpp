#include <bits/stdc++.h>
using namespace std;

#define int long long
#define rep(a, b, c) for (int a = b; a <= c; ++a)
#define inrange(x, l, r) assert((l) <= (x) && (x) <= (r))

int n;
int a[500005];

void solve() {
    cin >> n;
    rep(i, 1, n) {
        cin >> a[i];
    }
    inrange(n, 1, 500000);
    rep(i, 1, n) {
        inrange(a[i], -1e9, 1e9);
        assert(a[i] != 0);
    }
    int ans = 0;
    int cur = 0, cnt = 0;
    rep(i, 1, n) {
        if (a[i] * cur >= 0) {
            ans = max(ans, cnt);
            cnt = 0;
        }
        ++cnt;
        cur = a[i];
    }
    ans = max(ans, cnt);
    cout << ans << '\n';
}

signed main() {
    freopen("wave.in", "r", stdin);
    freopen("wave.out", "w", stdout);
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--) solve();
}