#include <bits/stdc++.h>

int main() {
  freopen("sqare.in", "r", stdin);
  freopen("sqare.out", "w", stdout);
  int n, m;
  std::cin >> n >> m;
  std::vector<std::vector<int>> a(n + 1, std::vector<int>(m + 1));
  for (int i = 1; i <= n; ++i) {
    for (int j = 1; j <= m; ++j) {
      std::cin >> a[i][j];
    }
  }
  using ll = long long;
  const ll INF = 0x3f3f3f3f3f3f3f3f;
  auto modify = [](ll &x, ll y) {
    x = std::max(x, y);
  };
  std::vector<std::vector<std::vector<ll>>> f(n + 1, std::vector<std::vector<ll>> (m + 1, std::vector<ll>(m + 1, -INF)));
  for (int i = 1; i <= n; ++i) {
    if (i == 1) {
      for (int j = 1; j <= m; ++j) f[i][j][j] = a[i][j];
    }
    for (int len = 1; len <= m; ++len) {
      for (int l = 1; l <= m; ++l) {
        int r = l + len - 1;
        if (r > m) break;
        if (l > 1) modify(f[i][l - 1][r], f[i][l][r] + a[i][l - 1]);
        if (r < m) modify(f[i][l][r + 1], f[i][l][r] + a[i][r + 1]);
        if (i < n) {
          for (int j = l; j <= r; ++j) {
            modify(f[i + 1][j][j], f[i][l][r] + a[i + 1][j]);
          }
        }
      }
    }
  }
  ll ans = LONG_MIN;
  for (int i = 1; i <= n; ++i) {
    for (int l = 1; l <= m; ++l) {
      for (int r = l; r <= m; ++r) {
        ans = std::max(ans, f[i][l][r]);
      }
    }
  }
  std::cout << ans << std::endl;
}