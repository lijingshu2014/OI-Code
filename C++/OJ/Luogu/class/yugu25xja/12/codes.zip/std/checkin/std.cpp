#include <bits/stdc++.h>

int main() {
  freopen("checkin.in", "r", stdin);
  freopen("checkin.out", "w", stdout);
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  int T;
  for (std::cin >> T; T; --T) {
    using ll = long long;
    ll a, b, p;
    std::cin >> a >> b >> p;
    int x = 0;
    ll cur = 1;
    int ans = -1;
    for (int i = 0; i < p; ++i) if (cur == b) {
      ans = x; break;
    } else {
      cur = cur * a % p;
      ++x;
    }
    if (ans == -1) {
      std::cout << "No Solution\n";
    } else {
      std::cout << x << '\n';
    }
  }
}