#include <bits/stdc++.h>

int main() {
  freopen("paper.in", "r", stdin);
  freopen("paper.out", "w", stdout);
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  int n, k;
  std::cin >> n >> k;
  std::vector<std::vector<int>> a(n, std::vector<int>(k));
  for (auto &i : a) 
    for (auto &j : i) 
      std::cin >> j;
  std::vector<std::map<int, int>> oc(k);
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < k; ++j) {
      ++oc[j][a[i][j]];
    }
  }
  std::vector<int> b(n), c(n);
  for (int i = 0; i < n; ++i) {
    for (int j = 0; j < k; ++j) {
      b[i] = std::max(b[i], oc[j][a[i][j]] - 1);
    }
    ++c[b[i]];
  }
  for (int i = 1; i < n; ++i) c[i] += c[i - 1];
  for (int i = 0; i < n; ++i) {
    if (i == 0) std::cout << 0;
    else std::cout << ' ' << c[i - 1];
  }
  std::cout << std::endl;
}