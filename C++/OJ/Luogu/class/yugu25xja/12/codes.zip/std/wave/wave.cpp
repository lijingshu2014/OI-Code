#include <bits/stdc++.h>

int main() {
  freopen("wave.in", "r", stdin);
  freopen("wave.out", "w", stdout);
  std::ios::sync_with_stdio(false);
  std::cin.tie(nullptr);
  int n;
  std::cin >> n;
  std::vector<int> a(n), f(n);
  for (auto &i : a) std::cin >> i;
  for (int i = 0; i < n; ++i) {
    f[i] = 1;
    if (i && 1ll * a[i] * a[i - 1] < 0) f[i] = f[i - 1] + 1;
  }
  std::cout << *std::max_element(f.begin(), f.end()) << std::endl;
}