#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
namespace fast_io {
	char buf[1<<12],*p1=buf,*p2=buf,sr[1<<23],z[23],nc;int C=-1,Z=0,Bi=0,ny;
	char gc() {return p1==p2&&(p2=(p1=buf)+fread(buf,1,1<<12,stdin),p1==p2)?EOF:*p1++;}
	ll read() {
		ll x=0;ny=1;while(nc=gc(),(nc<48||nc>57)&&nc!=EOF)if(nc==45)ny=-1;Bi=1;if(nc<0)return nc;
		x=nc-48;while(nc=gc(),47<nc&&nc<58&&nc!=EOF)x=(x<<3)+(x<<1)+(nc^48),Bi++;return x*ny;
	}
	db gf() {int a=read(),y=ny,b=(nc!='.')?0:read();return(b?a+(db)b/pow(10,Bi)*y:a);}
	int gs(char *s) {char c,*t=s;while(c=gc(),c<=32);*s++=c;while(c=gc(),c>32)*s++=c;return s-t;}
	void ot() {fwrite(sr,1,C+1,stdout);C=-1;}
	void flush() {if(C>1<<22) ot();}
	template <typename T>
	void write(T x,char t) {
		int y=0;if(x<0)y=1,x=-x;while(z[++Z]=x%10+48,x/=10);
		if(y)z[++Z]='-';while(sr[++C]=z[Z],--Z);sr[++C]=t;flush();
	}
	void write(char *s) {int l=strlen(s);for(int i=0;i<l;i++)sr[++C]=*s++;sr[++C]='\n';flush();}
}
using namespace fast_io;
const int N=5e5+5,M=21;
int n,m,k,d[N],dep[N],p[N][M],f[2][N][M];
vector<int>e[N];
void add(int x,int y) {e[x].push_back(y),e[y].push_back(x);}
void dfs(int u,int fa) {
    dep[u]=dep[fa]+1;
    p[u][0]=fa;
    f[0][u][0]=min(3*d[u]+dep[u],3*d[fa]+dep[fa]);
    f[1][u][0]=min(3*d[u]-dep[u],3*d[fa]-dep[fa]);
    for(int i=1;i<M;i++) {
        p[u][i]=p[p[u][i-1]][i-1];
        f[0][u][i]=min(f[0][u][i-1],f[0][p[u][i-1]][i-1]);
        f[1][u][i]=min(f[1][u][i-1],f[1][p[u][i-1]][i-1]);
	}
    for(int v:e[u])
		if(v^fa)
			dfs(v,u);
}
int lca(int x,int y) {
    if(dep[x]>dep[y]) swap(x,y);
    int l=dep[y]-dep[x];
    for(int i=0;i<M;i++)
        if((l>>i)&1)
            y=p[y][i];
    if(x==y)
        return x;
    for(int i=M-1;i>=0;i--)
        if(p[x][i]^p[y][i])
            x=p[x][i],y=p[y][i];
    return p[x][0];
}
int solve(int x,int y) {
    int z=lca(x,y),len=dep[x]+dep[y]-(dep[z]<<1);
    int ans=len*2;
    int tx=dep[x]-dep[z],ty=dep[y]-dep[z];
    int dx=dep[x],dy=dep[y];
    for(int i=0;i<M;i++)
        if((tx>>i)&1) {
            ans=min(ans,len+dx+f[1][x][i]);
            x=p[x][i];
        }
    for(int i=0;i<M;i++)
        if((ty>>i)&1) {
            ans=min(ans,len*2-dy+f[0][y][i]);
            y=p[y][i];
        }
    return ans;
}
int main() {
	n=read(),k=read();
	for(int i=1;i<n;i++) add(read(),read());
    queue<int>q;
	memset(d+1,-1,4*n);
    for(int i=1;i<=k;i++) {
        int x=read();
        q.push(x);
        d[x]=0;
    }
    while(!q.empty()) {
        int u=q.front();q.pop();
        for(int v:e[u])
            if(d[v]==-1) {
                d[v]=d[u]+1;
                q.push(v);
            }
    }
    d[0]=1e8;
    dfs(1,0);
	m=read();
    while(m--) {
        int x=read(),y=read();
		write(solve(x,y),'\n');
    }
    return ot(),0;
}