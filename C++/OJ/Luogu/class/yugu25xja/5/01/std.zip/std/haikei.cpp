#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=1e6+5;
int n,m;
ll a[N];
int main() {
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++) {
		int x;
		scanf("%d",&x);
		a[x]+=i;
	}
	while(m--) {
		int x,y;
		scanf("%d%d",&x,&y);
		printf("%lld\n",a[x]*a[y]);
	}
	return 0;
}