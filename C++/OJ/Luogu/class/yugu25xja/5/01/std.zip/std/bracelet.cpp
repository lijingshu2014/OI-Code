#include <iostream>
#include <string>
using namespace std;

int ask(char *s) {
    if (s[0] == '0' && s[1] == '0') return 0;
    else if (s[0] == '1' && s[1] == '1') return 2;
    else return 1;
}

int main() {
    int n, m, k;
    string s;
    cin >> n >> m >> k >> s;
    int len = s.length();
    s += s;
    int ans = 0;
    int cnt[3] = {n, m, k};
    for (int i = 0, j = 0; i < 2 * len - 1; i += 2) {
        ans = max(ans, i - j);
        int type = ask(&s[i]);
        while (j < i && cnt[type] == 0) {
            cnt[ask(&s[j])]++;
            j += 2;
        }
        if (cnt[type] == 0) j += 2;
        else cnt[type]--;
    }
    cnt[0] = n;
    cnt[1] = m;
    cnt[2] = k;
    for (int i = 1, j = 1; i < 2 * len - 1; i += 2) {
        ans = max(ans, i - j);
        int type = ask(&s[i]);
        while (j < i && cnt[type] == 0) {
            cnt[ask(&s[j])]++;
            j += 2;
        }
        if (cnt[type] == 0) j += 2;
        else cnt[type]--;
    }
    ans = min(ans, len / 2 * 2);
    printf("%d\n", ans);
}