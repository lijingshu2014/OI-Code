#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int N=5e5+5;
int n,a[N],b[N];
void solve() {
	scanf("%d",&n);
    for(int i=1;i<=n;i++) scanf("%d",a+i);
    for(int i=1;i<=n;i++) scanf("%d",b+i);
    ll l=0,r=1e9;
    while(l<=r) {
        ll mid=(l+r)/2,x=-1e18,y=1e18;
        for(int i=1;i<=n;i++) {
            x=max(x,a[i]-mid*b[i]);
            y=min(y,a[i]+mid*b[i]);
        }
        if(x<=y)
            r=mid-1;
        else
            l=mid+1;
    }
	printf("%lld\n",r+1);
}

int main() {
    int T;
	scanf("%d",&T);
    while (T--)
        solve();
    return 0;
}