#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 10;
int n, k, a[N], ans;

int main() {
    cin >> n >> k;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 2; i <= n; i++) a[i] += a[i - 1];
    for (int i = k + 1; i <= n; i++) ans = max(ans, a[i] - a[i - k - 1]);
    cout << ans << "\n";
    return 0;
}