#include <bits/stdc++.h>
using namespace std;

int n, s, a[100010];
long long sum;

int main() {
    freopen("rangesum1.in", "r", stdin);
    freopen("rangesum1.out", "w", stdout);
    cin >> n >> s;
    int l = 1; int ans = n + 1;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        sum += a[i];
        while (l <= i && sum - a[l] >= s) sum -= a[l], l++;
        if (sum >= s) ans = min(ans, i - l + 1);
    }
    cout << ans << "\n";
    return 0;
}