#include <bits/stdc++.h>
#define mod 998244353

using namespace std;

void inc(int &x, int y) {
    x += y; if (x >= mod) x -= mod;
}

const int N = 1005;
int n, m, c, f, suf[N][N], d[N][N], sumc[N][N], sumf[N][N], ansc, ansf; char s[N][N];

void solve() {
    scanf("%d%d%d%d", &n, &m, &c, &f);
    for (int i = 1; i <= n; i++) {
        scanf("%s", s[i] + 1);
        suf[i][m + 1] = 0;
    }
    for (int i = 1; i <= m; i++) d[n + 1][i] = sumc[n + 1][i] = sumf[n + 1][i] = 0;
    ansc = ansf = 0;
    for (int i = n; i >= 1; i--)
        for (int j = m; j >= 1; j--) {
            if (s[i][j] == '1') suf[i][j] = d[i][j] = sumc[i][j] = sumf[i][j] = 0;
            else {
                suf[i][j] = suf[i][j + 1] + 1, d[i][j] = d[i + 1][j] + 1;
                inc(sumc[i][j] = sumc[i + 1][j], suf[i][j] - 1);
                sumf[i][j] = (sumf[i + 1][j] + (d[i][j] - 1ll) * (suf[i][j] - 1ll)) % mod;
                if (i + 2 <= n && s[i + 1][j] == '0') {
                    ansc = (ansc + (suf[i][j] - 1ll) * sumc[i + 2][j]) % mod;
                    ansf = (ansf + (suf[i][j] - 1ll) * sumf[i + 2][j]) % mod;
                }
            }
        }
    printf("%d %d\n", ansc * c, ansf * f);
}

int main() {
    int T, id; scanf("%d%d", &T, &id);
    while (T--) solve();
    return 0;
}