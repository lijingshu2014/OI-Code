#include <bits/stdc++.h>
using namespace std;

int gcd(int x, int y) {
    return y == 0 ? x : gcd(y, x % y);
}
const int N = 1e3 + 10;
int n, m, a[N], dp[N][N];

int main() {
    cin >> n >> m;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int l = 1; l <= n; l++) {
        int now = 0;
        for (int r = l; r <= n; r++) dp[l][r] = now = gcd(a[r], now);
    }
    for (int i = 1; i <= m; i++) {
        int l, r; cin >> l >> r;
        cout << dp[l][r] << "\n";
    }
    return 0;
}