#include <bits/stdc++.h>
using namespace std;

string s, t; int k;

int main() {
    cin >> s >> t; cin >> k;
    if (k == 1) {
        cout << (s == t ? "YES\n" : "NO\n");
    }
    if (k == 2) {
        bool flag = false;
        for (int i = 1; i < s.size(); i++) {
            string s1 = s.substr(0, i);
            string s2 = s.substr(i);
            if (t == s1 + s2 || t == s2 + s1) flag = true;
        }
        cout << (flag ? "YES\n" : "NO\n");
    }
    if (k == 3) {
        bool flag = false;
        for (int i = 1; i < s.size(); i++)
            for (int j = 1; i + j < s.size(); j++) {
                string s1 = s.substr(0, i);
                string s2 = s.substr(i, j);
                string s3 = s.substr(i + j);
                if (t == s1 + s2 + s3) flag = true;
                if (t == s1 + s3 + s2) flag = true;
                if (t == s2 + s1 + s3) flag = true;
                if (t == s2 + s3 + s1) flag = true;
                if (t == s3 + s1 + s2) flag = true;
                if (t == s3 + s2 + s1) flag = true;
            }
        cout << (flag ? "YES\n" : "NO\n");
    }
    return 0;
}