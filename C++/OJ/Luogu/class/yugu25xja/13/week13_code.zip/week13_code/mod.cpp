#include <bits/stdc++.h>
using namespace std;

int a, b; bool vis[100010];

int main() {
    cin >> a >> b;
    a %= b;
    int t = a;
    while (!vis[t]) {
        vis[t] = true;
        t = 1ll * t * a % b;
    }
    for (int i = 0; i < b; i++) if (vis[i]) {
        cout << i << "\n";
        return 0;
    }
}