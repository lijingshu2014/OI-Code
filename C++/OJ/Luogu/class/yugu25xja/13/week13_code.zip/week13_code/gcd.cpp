#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 1e6 + 10;
int n, a[N]; ll ans[N], res;
vector<int> adj[N];
vector<pair<int, int>> s[N];

int gcd(int x, int y) {
    return y == 0 ? x : gcd(y, x % y);
}

void dfs(int u, int fa) {
//	cout << u << " " << fa << "\n";
    vector<pair<int, int>> tmp;
    tmp.emplace_back(a[u], 1);
    for (auto [p, q] : s[fa]) {
        int o = gcd(p, a[u]);
        if (tmp.back().first == o) tmp.back().second += q;
        else tmp.emplace_back(o, q);
    }
    swap(s[u], tmp);
    ans[u] = ans[fa];
    for (auto [p, q] : s[u]) {
    	ans[u] += 1ll * p * q;
    }
    // cout << u << " " << ans[u] << "\n";
    res ^= ans[u];
    for (int v : adj[u]) {
        if (v == fa) continue;
        dfs(v, u);
    }
}

int main() {
//    freopen("gcd1.in", "r", stdin);
//    freopen("gcd1.out", "w", stdout);
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i < n; i++) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    for (int i = 1; i <= n; i++) cin >> a[i];
    dfs(1, 0);
    cout << res << "\n";
    return 0;
}
