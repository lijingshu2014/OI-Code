#include<bits/stdc++.h>
using namespace std;
long long n,m,ans,color,number[100010];
long long sum1[100010][2],sum2[100010][2],sum3[100010][2],num[100010][2];
int main()
{
	scanf("%lld%lld",&n,&m);
	for(int i=1;i<=n;i++)
		scanf("%lld",&number[i]);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&color);
		sum1[color][i&1]=(sum1[color][i&1]+i)%10007;
		sum2[color][i&1]=(sum2[color][i&1]+number[i])%10007;
		sum3[color][i&1]=(sum3[color][i&1]+i*number[i])%10007;
		num[color][i&1]++;num[color][i&1]%=10007;
	}
	for(int i=1;i<=m;i++)
	for(int j=0;j<2;j++)
	if(num[i][j]>1)
		ans=(ans+sum1[i][j]*sum2[i][j]+sum3[i][j]*(num[i][j]-2))%10007;
	printf("%lld",ans);
	return 0;
}