#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10, mod = 1e9 + 7;
int n, g, a[N], nex[N]; long long ans;

int main() {
    cin >> n >> g;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        if (a[i] % g == 0) a[i] = 1;
        else a[i] = 0;
    }
    nex[n] = n + 1;
    nex[n + 1] = n + 1;
    for (int i = n - 1; i >= 1; i--) {
        if (a[i + 1] == 0) nex[i] = i + 1;
        else nex[i] = nex[i + 1];
    }
    for (int i = 1; i <= n; i++) {
        if (a[i] == 0) ans += nex[i] - i - 1;
        else ans += nex[nex[i]] - i - 1;
    }
    cout << ans << "\n";
    return 0;
}