#include <bits/stdc++.h>
using namespace std;

const int N = 16, mod = 1e9 + 7;
int k, c[N], cnt[6], dp[N][N][N][N][N][6], ans;

int dfs(int c1, int c2, int c3, int c4, int c5, int las) {
    if (dp[c1][c2][c3][c4][c5][las] != -1) return dp[c1][c2][c3][c4][c5][las];
    int res = 0;
    if (c1 > 0) res = (res + 1ll * (c1 - (las == 1)) * dfs(c1 - 1, c2, c3, c4, c5, 0)) % mod;
    if (c2 > 0) res = (res + 1ll * (c2 - (las == 2)) * dfs(c1 + 1, c2 - 1, c3, c4, c5, 1)) % mod;
    if (c3 > 0) res = (res + 1ll * (c3 - (las == 3)) * dfs(c1, c2 + 1, c3 - 1, c4, c5, 2)) % mod;
    if (c4 > 0) res = (res + 1ll * (c4 - (las == 4)) * dfs(c1, c2, c3 + 1, c4 - 1, c5, 3)) % mod;
    if (c5 > 0) res = (res + 1ll * (c5 - (las == 5)) * dfs(c1, c2, c3, c4 + 1, c5 - 1, 4)) % mod;
    return dp[c1][c2][c3][c4][c5][las] = res;
}

int main() {
    cin >> k;
    for (int i = 1; i <= k; i++) cin >> c[i], cnt[c[i]]++;
    memset(dp, -1, sizeof(dp));
    for (int i = 0; i <= 5; i++) dp[0][0][0][0][0][i] = 1;
    cout << dfs(cnt[1], cnt[2], cnt[3], cnt[4], cnt[5], 0) << "\n";
    return 0;
}