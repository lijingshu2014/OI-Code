#include <bits/stdc++.h>
using namespace std;

const int N = 105, mod = 1e9 + 7;
int n, m, dp[N][N][N], g[N][N]; bool vis[N][N][N]; char s[N][N];

void inc(int &x, int y) {
    x += y; if (x >= mod) x -= mod;
}
void dec(int &x, int y) {
    x -= y; if (x < 0) x += mod;
}

int main() {
    cin >> n >> m;
    for (int i = n; i >= 1; i--)
        for (int j = 1; j <= m; j++) cin >> s[i][j];
    for (int i = 1; i <= n; i++) {
        for (int l = 1; l <= m; l++) {
            if (s[i][l] == 'X') continue;
            vis[i][l][l] = true;
            for (int r = l + 1; r <= m; r++) {
                if (s[i][r] == 'X') break;
                vis[i][l][r] = true;
            }
        }
    }
    int ans = 1;
    for (int l = 1; l <= m; l++)
        for (int r = l; r <= m; r++) if (vis[1][l][r]) dp[1][l][r] = 1, inc(ans, 1);
    for (int k = 2; k <= n; k++) {
        for (int i = 1; i <= m; i++)
            for (int j = m; j >= i; j--) {
                g[i][j] = dp[k - 1][i][j];
                inc(g[i][j], g[i - 1][j]);
                inc(g[i][j], g[i][j + 1]);
                dec(g[i][j], g[i - 1][j + 1]);
            }
        for (int l = 1; l <= m; l++)
            for (int r = l; r <= m; r++) if (vis[k][l][r]) dp[k][l][r] = g[l][r], inc(ans, g[l][r]);
    }
    cout << ans << "\n";
    return 0;
}