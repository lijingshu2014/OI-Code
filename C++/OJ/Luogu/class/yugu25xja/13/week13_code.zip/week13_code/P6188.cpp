#include <bits/stdc++.h>
using namespace std;

int a = -1, b = -1, c = -1;
int min(int x, int y, int z) {
    return min(x, min(y, z));
}
void cmp(int i, int j, int k) {
    if (min(a, b, c) < min(i, j, k)) a = i, b = j, c = k;
    else if (min(a, b, c) == min(i, j, k) && a + b + c < i + j + k) a = i, b = j, c = k;
}

int main() {
    int n; cin >> n;
    for (int i = 0; i * 7 <= n; i++) {
        if ((n - i * 7) % 4 == 0) {
            int j = (n - i * 7) / 4;
            int k = (i + 1) / 2;
            cmp(i - k, j + k, k);
        }
        if ((n - i * 7) % 3 == 0) {
            int k = (n - i * 7) / 3;
            int j = (i + 1) / 2;
            cmp(i - j, j, k + j);
        }
    }
    if (a == -1) cout << "-1\n";
    else cout << a << " " << b << " " << c << "\n";
    return 0;
}