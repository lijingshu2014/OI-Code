#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 10;
int n, MIN = 0x3f3f3f3f;
stack<int> s1;

int main() {
    freopen("stack10.in", "r", stdin);
    freopen("stack10.out", "w", stdout);
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int op; cin >> op;
        if (op == 1) { // 入栈
            int x; cin >> x;
            s1.push(x - MIN);
            MIN = min(MIN, x);
        }
        else if (op == 2) { // 出栈,并输出栈顶对应的原数
            if (s1.size() == 0) {
                cout << "ERROR\n";
                return 0;
            }
            if (s1.top() < 0) cout << MIN << "\n", MIN -= s1.top();
            else cout << s1.top() + MIN << "\n";
            s1.pop();
        }
        else { // 查询最小值
            cout << MIN << "\n";
        }
    }
    return 0;
}