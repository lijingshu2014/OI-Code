#include <bits/stdc++.h>
using namespace std;

int q; long long x, las, ans;

int main() {
    cin >> q;
    int i = 1;
    while (q--) {
        cin >> x;
        for ( ; las < x; i++) {
            long long now = min(x, (i + 1ll) * (i + 1) * (i + 1) - 1);
            ans += (now - las) * i;
            las = now;
        }
        i--;
        cout << ans << "\n";
    }
    return 0;
}