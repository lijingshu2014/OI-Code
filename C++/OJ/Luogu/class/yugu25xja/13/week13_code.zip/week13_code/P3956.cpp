#include<bits/stdc++.h>
using namespace std;
int m,n,x,y,c,b[110][110],f[110][110];
const int fx[]={-1,0,0,1};
const int fy[]={0,-1,1,0};
void dfs(int dx,int dy,int last,int s)
{
	if(dx==0||dx>m||dy==0||dy>m) return;
	if(last==0&&b[dx][dy]==0) return;
	if(f[dx][dy]<=s) return;
	else f[dx][dy]=s;
	for(int i=0;i<4;i++)
	{
		int w=dx+fx[i];
		int u=dy+fy[i];
		if(b[dx][dy]==0)
		{
			if(last==b[w][u]) dfs(w,u,last,s);
			else if(last!=b[w][u]&&b[w][u]) dfs(w,u,last,s+1);
		}
		if(b[w][u]==b[dx][dy]) dfs(w,u,b[dx][dy],s);
		else if(b[w][u]!=b[dx][dy]&&b[w][u]) dfs(w,u,b[dx][dy],s+1);
		else if(b[w][u]!=b[dx][dy]&&!b[w][u]) dfs(w,u,b[dx][dy],s+2);
	}
}
int main()
{
	//freopen("chess.in","r",stdin);
	//freopen("chess.out","w",stdout);
	scanf("%d%d",&m,&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&x,&y,&c);
		b[x][y]=c+1;
	}
	for(int i=1;i<=m;i++)
		for(int j=1;j<=m;j++)
			f[i][j]=10000000;
	dfs(1,1,1,0);
	if(f[m][m]!=10000000) cout<<f[m][m]<<endl;
	else cout<<"-1"<<endl;
	return 0;
}