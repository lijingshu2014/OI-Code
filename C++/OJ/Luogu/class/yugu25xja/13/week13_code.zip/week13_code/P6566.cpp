#include <bits/stdc++.h>
using namespace std;

const int N = 1510;
const int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1};
const int dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};
int n, m, cnt, res, ans, t[100010]; char s[N][N];

void dfs(int x, int y) {
    if (x < 1 || x > n || y < 1 || y > m || s[x][y] == '.') return ;
    s[x][y] = '.'; res++;
    for (int i = 0; i < 8; i++) dfs(x + dx[i], y + dy[i]);
}

int main() {
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) cin >> s[i][j];
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) 
            if (s[i][j] == '*') {
                res = 0;
                dfs(i, j);
                if (!t[res]) cnt++;
                t[res] += res;
                ans = max(ans, t[res]);
            }
    }
    cout << cnt << " " << ans << "\n";
    return 0;
}