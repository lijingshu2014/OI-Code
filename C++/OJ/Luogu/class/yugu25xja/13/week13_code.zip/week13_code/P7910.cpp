#include <bits/stdc++.h>
using namespace std;

const int N = 8e3 + 10;
int n, Q, a[N], pos[N];
pair<int, int> p[N];

int main() {
    cin >> n >> Q;
    for (int i = 1; i <= n; i++) cin >> a[i], p[i] = {a[i], i};
    for (int i = 2; i <= n; i++) {
        for (int j = i; j >= 2; j--)
            if (p[j - 1] > p[j]) {
                swap(p[j], p[j - 1]);
            }
    }
    for (int i = 1; i <= n; i++) pos[p[i].second] = i;
    while (Q--) {
        int op, x; cin >> op >> x;
        if (op == 1) {
            int v, i; cin >> v;
            for (i = 1; i <= n; i++)
                if (p[i].second == x) break;
            if (p[i].first > v) {
                p[i].first = v;
                for (int j = i; j >= 2; j--) {
                    if (p[j - 1] > p[j]) {
                        swap(pos[p[j - 1].second], pos[p[j].second]);
                        swap(p[j - 1], p[j]);
                    }
                }
            }
            else if (p[i].first < v) {
                p[i].first = v;
                for (int j = i; j < n; j++) {
                    if (p[j] > p[j + 1]) {
                        swap(pos[p[j + 1].second], pos[p[j].second]);
                        swap(p[j + 1], p[j]);
                    }
                }
            }
        }
        else {
            cout << pos[x] << "\n";
        }
    }
    return 0;
}