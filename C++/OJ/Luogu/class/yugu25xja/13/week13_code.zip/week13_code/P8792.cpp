#include <bits/stdc++.h>
using namespace std;

int gcd(int x, int y) {
    return y == 0 ? x : gcd(y, x % y);
}
const int N = 1e5 + 10;
int n, a[N], Log[N], st[18][N], res = 1e9, cnt;

void init() {
    Log[0] = -1;
    for (int i = 1; i <= n; i++) st[0][i] = a[i], Log[i] = Log[i >> 1] + 1;
    for (int j = 1; (1 << j) <= n; j++)
        for (int i = 1; i + (1 << j) - 1 <= n; i++)
            st[j][i] = gcd(st[j - 1][i], st[j - 1][i + (1 << (j - 1))]);
}
int GCD(int l, int r) {
    int t = Log[r - l + 1];
    return gcd(st[t][l], st[t][r - (1 << t) + 1]);
}

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        if (a[i] == 1) cnt++;
    }
    if (cnt > 0) {
        cout << n - cnt << "\n";
        return 0;
    }
    init();
    for (int l = n, r = n; l >= 1; l--) {
        if (GCD(l, r) > 1) continue;
        while (l < r && GCD(l, r - 1) == 1) r--;
        res = min(res, r - l);
    }
    if (res == (int)(1e9)) cout << "-1\n";
    else cout << res + (n - 1) << "\n";
    return 0;
}