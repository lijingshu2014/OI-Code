#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 10;
int n, sze[N];
vector<int> adj[N], ans;

void dfs(int u, int fa) {
    sze[u] = 1;
    vector<int> tmp;
    for (int v : adj[u]) {
        if (v == fa) continue;
        dfs(v, u);
        sze[u] += sze[v];
        tmp.push_back(sze[v]);
    }
    if (fa) tmp.push_back(n - sze[u]);
    bool flag = true;
    for (int i = 1; i < tmp.size(); i++) if (tmp[i] != tmp[i - 1]) flag = false;
    if (flag) ans.push_back(u);
}

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i < n; i++) {
        int u, v; cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    dfs(1, 0);
    sort(ans.begin(), ans.end());
    for (int val : ans) cout << val << " ";
    return 0;
}