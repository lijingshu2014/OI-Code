#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 1e5 + 10;
int n, k, a[N];

int check(ll x) {
    int cnt = 1; ll s = 0;
    for (int i = 1; i <= n; i++) {
        s += a[i];
        if (s < 0) s = 0;
        if (s > x) {
            cnt++;
            s = a[i];
            if (a[i] > x) return k + 1;
        }
    }
    return cnt;
}

int main() {
    // freopen("minmax10.in", "r", stdin);
    // freopen("minmax10.out", "w", stdout);
    cin >> n >> k;
    ll L = 0, R = 0, o = 0;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
        o += a[i];
        if (o < 0) o = 0;
        R = max(R, o);
    }
    ll ans = R;
    while (L <= R) {
        ll mid = (L + R) / 2;
        if (check(mid) <= k) ans = mid, R = mid - 1;
        else L = mid + 1;
    }
    cout << ans << "\n";
    return 0;
}
