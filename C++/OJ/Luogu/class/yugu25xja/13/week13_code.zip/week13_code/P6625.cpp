#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 10;
int n;
long long a[N], ans;

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 2; i <= n; i++) {
        a[i] += a[i - 1];
        if (a[i] > 0) ans += a[i];
    }
    cout << ans << "\n";
    return 0;
}