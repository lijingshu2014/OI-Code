#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, a[N]; long long ans = 0;

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i], ans += a[i];
    int mx = 0;
    sort(a + 1, a + n + 1);
    for (int i = 1; i < n; i++) mx = max(mx, a[n] - a[n] % a[i]);
    cout << ans - mx << "\n";
    return 0;
}