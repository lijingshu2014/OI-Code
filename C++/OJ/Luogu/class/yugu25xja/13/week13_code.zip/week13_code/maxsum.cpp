#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, k, a[N];
long long dp[11][N][2];

int main() {
    // freopen("maxsum10.in", "r", stdin);
    // freopen("maxsum10.out", "w", stdout);
    cin >> n >> k;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int j = 1; j <= k; j++) {
        for (int i = j; i <= n; i++) {
            dp[j][i][0] = max(dp[j][i - 1][0], dp[j][i - 1][1]);
            dp[j][i][1] = max(dp[j][i - 1][1], dp[j - 1][i - 1][0]) + a[i];
        }
    }
    cout << max(dp[k][n][0], dp[k][n][1]) << "\n";
    return 0;
}