#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, s[N], a[N], ans[N]; bool vis[N];
pair<int, int> qs[N], qa[N];

int main() {
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> s[i];
    for (int i = 1; i <= n; i++) cin >> a[i], qa[i] = {a[i], i}, qs[i] = {2 * s[i] + a[i], i};
    sort(qs + 1, qs + n + 1);
    sort(qa + 1, qa + n + 1);
    int j = n, k = n, mx = 0, res = 0;
    for (int i = 1; i <= n; i++) {
        while (j >= 1 && qs[j].second <= mx) j--;
        while (k >= 1 && vis[qa[k].second]) k--;
        if (qs[j].first - 2 * s[mx] >= qa[k].first) {
            res -= 2 * s[mx];
            res += qs[j].first;
            mx = qs[j].second;
            vis[qs[j].second] = true;
        }
        else {
            res += qa[k].first;
            vis[qa[k].second] = true;
        }
        ans[i] = res;
    }
    for (int i = 1; i <= n; i++) cout << ans[i] << "\n";
    return 0;
}