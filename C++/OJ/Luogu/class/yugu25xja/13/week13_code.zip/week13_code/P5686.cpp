#include <bits/stdc++.h>
using namespace std;

const int N = 5e5 + 10, mod = 1e9 + 7;
int n, a[N], b[N], pre[N], suf[N], ans;

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> a[i];
    for (int i = 1; i <= n; i++) cin >> b[i];
    for (int i = 1; i <= n; i++) {
        pre[i] = (pre[i - 1] + 1ll * a[i] * i) % mod;
    }
    for (int i = n; i >= 1; i--) {
        suf[i] = (suf[i + 1] + 1ll * a[i] * (n - i + 1ll)) % mod;
    }
    for (int i = 1; i <= n; i++) {
        ans = (ans + 1ll * b[i] * pre[i] % mod * (n - i + 1)) % mod;
        ans = (ans + 1ll * b[i] * suf[i + 1] % mod * i) % mod;
    }
    cout << ans << "\n";
    return 0;
}