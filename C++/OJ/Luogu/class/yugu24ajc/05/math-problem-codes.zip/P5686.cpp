#include<bits/stdc++.h>
using namespace std;

const int mod = 1000000000 + 7;
const int MAXN = 500000 + 7;
int n, a[MAXN], b[MAXN];
long long A[MAXN], B[MAXN], SA[MAXN], SB[MAXN], SAB[MAXN];

int main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
		A[i] = (A[i - 1] + a[i]) % mod;
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
		B[i] = (B[i - 1] + b[i]) % mod;
	}
	for(int i = 1; i <= n; i++) {
		SAB[i] = (SAB[i - 1] + A[i] * B[i] % mod) % mod;
		SA[i] = (SA[i - 1] + A[i]) % mod;
		SB[i] = (SB[i - 1] + B[i]) % mod;
	}
	long long ans = 0;
	for(int i = 1; i <= n; i++) {
		ans = (ans + ((SAB[n] - SAB[i - 1]) % mod + mod) % mod) % mod;
	}
	for(int i = 1; i <= n; i++) {
		ans = (ans + (n - i + 1) % mod * A[i - 1] % mod * B[i - 1] % mod) % mod;
	}
	for(int i = 1; i <= n; i++) {
		ans = (ans - (B[i - 1] * ((SA[n] - SA[i - 1]) % mod + mod) % mod) % mod) % mod;
	}
	for(int i = 1; i <= n; i++) {
		ans = (ans - (A[i - 1] * ((SB[n] - SB[i - 1]) % mod + mod) % mod) % mod) % mod;
	}
	ans = (ans % mod + mod) % mod;
	cout << ans;
}
