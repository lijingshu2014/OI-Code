#include<bits/stdc++.h>
using namespace std;

const int mod = 998244353;

int Q, x, y, n;
bool pr[100007];

void pre() {
	for(int i = 2; i <= 100000; i++) {
		if(pr[i]) continue;
		for(int j = i * 2; j <= 100000; j += i) {
			pr[j] = true;
		}
	}
}

int fpow(long long x, int p) {
	long long ret = 1;
	while(p) {
		if(p & 1) ret = ret * x % mod; p >>= 1;
		x = x * x % mod;
	} 
	return ret;
}

int main() {
	pre();
	cin >> Q;
	while(Q--) {
		cin >> x >> y >> n;
		y /= x;
		int lim = y;
		vector <int> c;
		for(int i = 2; i * i <= lim; i++) {
			if(pr[i]) continue;
			int cnt = 0;
			while(y % i == 0) {
				++cnt; y /= i;
			} 
			if(cnt != 0) c.push_back(cnt);
		}
		if(y > 1) c.push_back(1);
		long long ans = 1;
		for(auto val: c) {
			long long pval = ((fpow(val + 1, n) - 2 * fpow(val, n)) % mod + fpow(val - 1, n)) % mod;
			pval = (pval + mod) % mod;
			ans = ans * pval % mod;
		}
		cout << ans << endl;
	}
}
