#include<bits/stdc++.h>
using namespace std;
int n1,m1,f[2003][2003],dp[2003][2003];
int n,m,ans;
int main()
{
    cin>>n1>>m1;
    for (int i=1;i<=2002;i++) 
	{
        f[i][i]=1;
        f[i][1]=i%m1;
    }
    for (int i=2;i<=2002;i++) 
	{
        for (int j=2;j<=i-1;j++) 
		{
            f[i][j]=(f[i-1][j]%m1+f[i-1][j-1]%m1)%m1;
        }
    }
    for (int i=1;i<=2002;i++) 
	{
        for (int j=1;j<=i;j++) 
		{
            if(f[i][j]==0) 
			dp[i][j]=dp[i][j-1]+1;
            else 
			dp[i][j]=dp[i][j-1];
        }
    }
    for (int j=1;j<=n1;j++) 
	{
        cin>>n>>m;
        ans=0;
        for (int i=1;i<=n;i++) 
		{
            if(i>m) 
			ans+=dp[i][m];
            else 
			ans+=dp[i][i];
        }
        cout<<ans<<endl;
    }
    return 0;
}
