#include<bits/stdc++.h>
using namespace std;
#define int long long

int N, a[100000 + 7];
int S[100000 + 7], cnt[2], sum;

signed main() {
	cin >> N;
	for(int i = 1; i <= N; i++) cin >> a[i];
	for(int i = 0; i <= 20; i++) {
		for(int j = 1; j <= N; j++) {
			if((a[j] >> i) & 1) S[j] = S[j - 1] ^ 1;
			else S[j] = S[j - 1];
		}
		cnt[0] = cnt[1] = 0;
		for(int j = 0; j <= N; j++) {
			cnt[S[j]]++;
		}
		sum += (1ll << i) * cnt[0] * cnt[1];
	}
	cout << sum << endl;
}
