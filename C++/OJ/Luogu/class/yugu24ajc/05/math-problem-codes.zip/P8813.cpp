#include<bits/stdc++.h>
using namespace std;

int a, b;
const int limit = 1000000000;

long long fpow(long long x, int p) {
	long long ret = 1;
	while(p) {
		if(p & 1) ret = ret * x;
		x = x * x; p >>= 1;
		if(ret > limit || ret <= 0 || x <= 0) return -1;
	}
	return ret;
}

int main() {
	cin >> a >> b;
	int ans = fpow(a, b);
	cout << ans << endl;
	return 0;
}
