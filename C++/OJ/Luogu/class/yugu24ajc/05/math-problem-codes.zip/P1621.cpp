#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;

int a, b, p;
bool pr[MAXN];
int f[MAXN];

int find(int x) {
	if(f[x] == x) return f[x];
	return f[x] = find(f[x]);
}

bool cnt[MAXN];

int main() {
	cin >> a >> b >> p;
	for(int i = 1; i <= b; i++) f[i] = i;
	for(int i = 2; i <= b; i++) {
		if(pr[i]) continue;
		for(int j = i * 2; j <= b; j += i) {
			pr[j] = true;
			if(i >= p) {
				int fu = find(i), fv = find(j);
				if(fu != fv) f[fv] = fu;
			}
		}
	}
	int ans = 0;
	for(int i = a; i <= b; i++) {
		int fv = find(i);
		if(cnt[fv] == false) {
			cnt[fv] = true;
			ans++;
		}
	}
	cout << ans << endl;
	return 0;
}
