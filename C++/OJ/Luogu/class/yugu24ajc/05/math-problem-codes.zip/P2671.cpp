#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;
const int mod = 10007;

int n, m, val[MAXN], ans;
vector <pair<int, int> > vec[MAXN][2];

int main() {
	cin >> n >> m;
	for(int i = 1; i <= n; i++) {
		cin >> val[i];
	}
	for(int i = 1, c; i <= n; i++) {
		cin >> c;
		vec[c][i & 1].push_back(make_pair(i, val[i]));
	}
	for(int i = 1; i <= m; i++) {
		for(int j = 0; j <= 1; j++) {
			int w = vec[i][j].size();
			if(w == 0) continue;
			int S = 0;
			for(auto v: vec[i][j]) {
				S = (S + v.second) % mod;
			}
			for(auto v: vec[i][j]) {
				int val1 = 1ll * (w - 1) * v.first % mod * v.second % mod;
				int val2 = 1ll * v.first % mod * (S - v.second) % mod;
				ans = (ans + val1 + val2) % mod;
				ans = (ans + mod) % mod;
			}
		}
	}
	cout << ans << endl;
}
