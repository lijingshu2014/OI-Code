#include<bits/stdc++.h>
using namespace std;

mt19937 gen(time(0));
int rnd(int l, int r) {
	int p = gen(); p = abs(p);
	return p % (r - l + 1) + l;
}
// [l,r]

int main() {
	freopen("test.in", "w", stdout);
	int a = rnd(1, 200), b = rnd(1, 200);
	cout << a << endl << b << endl;
	return 0;
} 
