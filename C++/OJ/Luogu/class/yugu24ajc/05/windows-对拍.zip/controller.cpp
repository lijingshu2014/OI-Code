#include<bits/stdc++.h>
#include<windows.h>
using namespace std;

int main() {
	int cas = 0;
	while(true) {
		++cas;
		cout << "--------------- #" << cas << " ---------------------\n";
		system("data.exe");
		system("std.exe");
		system("test.exe");
		if(system("fc std.out test.out")) {
			break;
		}
		Sleep(200);
	}
}
