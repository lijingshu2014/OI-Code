#include<bits/stdc++.h>
using namespace std;

int main() {
	freopen("test.in", "r", stdin);
	freopen("test.out", "w", stdout);
	int a, b;
	cin >> a >> b;
	if(a > 150) {
		cout << "Why did I write this wrong?" << endl;
	}
	else cout << a + b << endl;
	return 0;
}
