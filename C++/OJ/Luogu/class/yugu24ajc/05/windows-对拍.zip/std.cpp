#include<bits/stdc++.h>
using namespace std;

int a, b;
int main() {
	freopen("test.in", "r", stdin);
	freopen("std.out", "w", stdout);
	cin >> a >> b;
	int ans = 0;
	for(int i = 1; i <= a; i++) {
		ans++;
	}
	for(int i = 1; i <= b; i++) {
		ans++;
	}
	cout << ans << endl;
	return 0;
}
