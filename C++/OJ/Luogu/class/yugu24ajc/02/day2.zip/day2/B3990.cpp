#include <bits/stdc++.h>
using namespace std;

bool check(string s, string t) {
    for (int i = 0; i < s.size(); i++)
        if (s[i] != t[i] && s[i] != '?' && t[i] != '?') return false;
    return true;
}

int main() {
    string s, t;
    cin >> s >> t;
    for (int i = 0; i + t.size() - 1 < s.size(); i++) {
        if (check(s.substr(i, t.size()), t)) 
            cout << i + 1 << " " << i + t.size() << "\n";
    }
    return 0;
}