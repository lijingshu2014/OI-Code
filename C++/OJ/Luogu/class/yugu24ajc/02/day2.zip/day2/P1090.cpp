#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    int n; cin >> n;
    priority_queue<int, vector<int>, greater<int> > heap;
    for (int i = 1; i <= n; i++) {
        int x; cin >> x;
        heap.push(x);
    }
    long long ans = 0;
    for (int i = 1; i < n; i++) {
        int p = heap.top(); heap.pop();
        int q = heap.top(); heap.pop();
        ans += p + q;
        heap.push(p + q);
    }
    cout << ans << "\n";
    return 0;
}