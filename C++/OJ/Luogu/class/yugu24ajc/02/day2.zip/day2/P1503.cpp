#include <bits/stdc++.h>
using namespace std;

const int N = 5e4 + 10;
int n, m, stk[N], tp;
set<int> s;

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n >> m;
    s.insert(0);
    s.insert(n + 1);
    for (int i = 1; i <= m; i++) {
        char op; cin >> op;
        if (op == 'D') {
            int x; cin >> x;
            s.insert(x);
            stk[++tp] = x;
        }
        else if (op == 'R') {
            s.erase(stk[tp--]);
        }
        else { 
            int x; cin >> x;
            auto it = s.lower_bound(x);
            if (*it == x) cout << "0\n";
            else {
                auto jt = it; jt--;
                cout << *it - *jt - 1 << '\n';
            }
        }
    }
    return 0;
}