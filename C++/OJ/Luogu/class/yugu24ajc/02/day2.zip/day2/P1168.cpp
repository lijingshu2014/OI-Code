#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, A[N], mid;
priority_queue<int> p, q;

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) cin >> A[i];
    cout << (mid = A[1]) << "\n";
    for (int i = 3; i <= n; i += 2) {
        if (A[i - 1] <= mid && A[i] <= mid) {
            p.push(A[i - 1]); p.push(A[i]);
            q.push(-mid);
            mid = p.top(); p.pop();
        }
        else if (A[i - 1] >= mid && A[i] >= mid) {
            p.push(mid);
            q.push(-A[i - 1]); q.push(-A[i]);
            mid = -q.top(); q.pop();
        }
        else {
            if (A[i - 1] > A[i]) swap(A[i - 1], A[i]);
            p.push(A[i - 1]);
            q.push(-A[i]);
        }
        cout << mid << "\n";
    }
    return 0;
}