#include  <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int n, m, nex[N], las[N];
bool vis[N];

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    nex[1] = n + 1, las[n + 1] = 1;
    las[1] = 0, nex[0] = 1;
    for (int i = 2; i <= n; i++) {
        int k, p; cin >> k >> p;
        if (p == 0) {
            las[i] = las[k]; nex[las[k]] = i;
            las[k] = i; nex[i] = k;
        }
        else {
            nex[i] = nex[k]; las[nex[k]] = i;
            nex[k] = i; las[i] = k;
        }
    }
    cin >> m;
    for (int i = 1; i <= m; i++) {
        int x; cin >> x;
        if (vis[x]) continue;
        vis[x] = true;
        nex[las[x]] = nex[x];
        las[nex[x]] = las[x];
    }
    int now = nex[0];
    while (now != n + 1) {
        cout << now << " ";
        now = nex[now];
    }
    // 删除 m 个元素并输出
    return 0;
}
