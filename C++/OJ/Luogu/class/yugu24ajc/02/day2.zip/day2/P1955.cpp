#include <bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;
int n, fa[N], a[N], b[N], e[N];
unordered_map<int, int> id;

int find(int x) {
    return fa[x] == x ? x : fa[x] = find(fa[x]);
}

void solve() {
    cin >> n;
    id.clear();
    for (int i = 1; i <= n; i++) {
        cin >> a[i] >> b[i] >> e[i];
        id[a[i]] = id[b[i]] = 1;
    }
    int cnt = 0;
    for (auto it = id.begin(); it != id.end(); it++) {
        it->second = ++cnt;
    }
    for (int i = 1; i <= cnt; i++) fa[i] = i;
    for (int i = 1; i <= n; i++) {
        a[i] = id[a[i]], b[i] = id[b[i]];
        if (e[i] == 1) {
            fa[find(a[i])] = find(b[i]);
        }
    }
    for (int i = 1; i <= n; i++)
        if (e[i] == 0 && find(a[i]) == find(b[i])) {
            cout << "NO\n";
            return ;
        }
    cout << "YES\n";
}

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    int T = 1; cin >> T;
    while (T--) solve();
    return 0;
}