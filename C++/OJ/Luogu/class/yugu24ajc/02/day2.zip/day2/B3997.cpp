#include <bits/stdc++.h>
using namespace std;

bool check(string s) {
    for (int i = 0; i < s.size() - 1 - i; i++) 
        if (s[i] != s[s.size() - 1 - i]) return false;
    return true;
}

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    string s; cin >> s;
    int ans = 0;
    for (int i = 0, j = 1; i < s.size(); i += j, j++) {
        if (check(s.substr(i, j))) ans++;
    }
    cout << ans << "\n";
    return 0;
}