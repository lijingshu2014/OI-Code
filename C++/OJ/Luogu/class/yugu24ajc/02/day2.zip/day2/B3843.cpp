#include <bits/stdc++.h>
using namespace std;

void check(string s) {
    if (s.size() < 6 || s.size() > 12) return ;
    int a = 0, b = 0, c = 0, d = 0;
    for (int i = 0; i < s.size(); i++) {
        if ('A' <= s[i] && s[i] <= 'Z') a = 1;
        else if ('a' <= s[i] && s[i] <= 'z') b = 1;
        else if ('0' <= s[i] && s[i] <= '9') c = 1;
        else if (s[i] == '!' || s[i] == '#' || s[i] == '@' || s[i] == '$') d = 1;
        else return ;
    }
    if ((a + b + c) >= 2 && d) cout << s << "\n";
}

int main() {
    string s; cin >> s;
    string t = "";
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == ',') check(t), t = "";
        else t += s[i];
    }
    check(t);
    return 0;
}