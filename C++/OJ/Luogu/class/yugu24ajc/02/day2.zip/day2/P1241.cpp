#include <bits/stdc++.h>
using namespace std;

const int N = 110;
int n; bool vis[N]; char s[N];
stack<int> stk;

int main() {
    cin >> s;
    n = strlen(s);
    for (int i = 0; i < n; i++) {
        if (s[i] == '(' || s[i] == '[') stk.push(i);
        else {
            if (stk.size() == 0) continue; 
            int j = stk.top();
            if (s[j] == '(' && s[i] == ')')  vis[j] = vis[i] = true, stk.pop();
            else if (s[j] == '[' && s[i] == ']') vis[j] = vis[i] = true, stk.pop();
        }
    }
    for (int i = 0; i < n; i++) 
        if (vis[i]) cout << s[i];
        else {
            if (s[i] == '(' || s[i] == ')') cout << "()";
            else cout << "[]";
        }
    return 0;
}