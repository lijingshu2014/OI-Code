#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
int p[N], t[N];

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    int n, ans = 0; queue<int> q;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int op;
        cin >> op >> p[i] >> t[i];
        if (op == 0) ans += p[i], q.push(i);
        else {
            while (!q.empty() && t[i] - t[q.front()] > 45) q.pop(); 
            queue<int> tmp; bool flag = false;
            while (!q.empty()) {
                int id = q.front(); q.pop();
                if (!flag && p[id] >= p[i]) flag = true;
                else tmp.push(id);
            }
            swap(q, tmp);
            if (!flag) ans += p[i]; 
        }
    }
    cout << ans << "\n";
    return 0;
}