#include <bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;
int n, a[N], NEXT[N];
int head[N], las[N], nex[N], cnt;

void print() {
    int u = NEXT[0];
    while (u != 0) {
        int i = head[u];
        while (i) cout << i << " ", i = nex[i];
        cout << "\n";
        u = NEXT[u];
    }
    cout << "\n";
}

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for (int l = 1; l <= n; l++) { 
        head[++cnt] = l, las[cnt] = l;
        int r = l + 1;
        while (r <= n && a[r] == a[l]) {
            nex[r - 1] = r;
            las[cnt] = r;
            r++;
        }
        NEXT[cnt - 1] = cnt;
        l = r - 1;
    }
    while (NEXT[0] != 0) {
        // print();
        int now = NEXT[0];
        while (now != 0) {
            cout << head[now] << " ";
            head[now] = nex[head[now]];
            now = NEXT[now];
        }
        cout << "\n";
        now = 0;
        while (NEXT[now] != 0) {
            if (!head[NEXT[now]]) {
                NEXT[now] = NEXT[NEXT[now]];
                if (now && NEXT[now]) {
                    nex[las[now]] = head[NEXT[now]];
                    if (head[NEXT[now]]) las[now] = las[NEXT[now]];
                    NEXT[now] = NEXT[NEXT[now]];
                }
            }
            else now = NEXT[now];
        }
    }
    return 0;
}