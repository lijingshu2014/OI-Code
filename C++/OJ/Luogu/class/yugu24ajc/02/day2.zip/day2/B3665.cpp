#include <bits/stdc++.h>
using namespace std;

const int N = 3e6 + 10;
int n, q, s[N]; unsigned int ans = 0;
vector<unsigned int> a[N];

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n >> q;
    for (int i = 1; i <= n; i++) {
        cin >> s[i];
        a[i].resize(s[i] + 1);
        for (int j = 1; j <= s[i]; j++) cin >> a[i][j];
    }
    for (int i = 1; i <= q; i++) {
        int x, y; cin >> x >> y;
        ans ^= a[x][y];
    }
    cout << ans << "\n";
    return 0;
}