#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 1e6 + 10;
int n, h[N], v[N];
ll ans[N];
stack<int> stk;

int main() {
    ios::sync_with_stdio(false), cin.tie(0);
    cin >> n;
    for (int i = 1; i <= n; i++) {
        cin >> h[i] >> v[i];
    }
    h[0] = h[n + 1] = INT_MAX;
    stk.push(0);
    for (int i = 1; i <= n; i++) {
        while (h[i] >= h[stk.top()]) stk.pop();
        ans[stk.top()] += v[i];
        stk.push(i);
    }
    while (stk.size()) stk.pop();
    stk.push(n + 1);
    for (int i = n; i >= 1; i--) {
        while (h[i] >= h[stk.top()]) stk.pop();
        ans[stk.top()] += v[i];
        stk.push(i);
    }
    ll mx = 0;
    for (int  i = 1; i <= n; i++) mx = max(mx, ans[i]);
    cout << mx << "\n";
    return 0;
}

