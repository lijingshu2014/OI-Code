#include <bits/stdc++.h>
using namespace std;

int main() {
	string s = "abd";
	cout << s.find("bd", 2) << "\n";
	cout << string::npos << "\n";
	cout << s.substr(1, 2) << "\n";
	cout << s.substr(2, 2) << "\n";
	s.insert(0, "ACAC");
	cout << s << '\n';
	s.replace(0, 2, "BD");
	cout << s << "\n";
	s.replace(s.begin(), s.begin() + 2, "AA");
	cout << s << "\n";
	return 0;
}
