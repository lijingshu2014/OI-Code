#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 10;
string s; int a[N], nodeid, ls[N], rs[N], ans1, ans2; char c[N];
stack<int> id;
stack<char> op;

int dfs(int u) {
    if (c[u] == '&') {
        int lans = dfs(ls[u]);
        if (lans == 0) {
            ans1++;
            return 0;
        }
        else return lans & dfs(rs[u]);
    }
    else if (c[u] == '|') {
        int lans = dfs(ls[u]);
        if (lans == 1) {
            ans2++;
            return 1;
        }
        else return lans | dfs(rs[u]);
    }
    else return a[u];
}

int main() {
    cin >> s;
    for (int i = 0; i < s.size(); i++) {
        if (s[i] == '0' || s[i] == '1') {
            a[++nodeid] = s[i] - '0';
            id.push(nodeid);
        }
        else {
            if (s[i] == '(') op.push(s[i]);
            else if (s[i] == ')') {
                while (op.top() != '(') {
                    c[++nodeid] = op.top(); op.pop();
                    int r = id.top(); id.pop();
                    int l = id.top(); id.pop();
                    ls[nodeid] = l, rs[nodeid] = r;
                    id.push(nodeid);
                }
                op.pop();
            }
            else if (s[i] == '&') {
                while (op.size() > 0 && op.top() == '&') {
                    c[++nodeid] = op.top(); op.pop();
                    int r = id.top(); id.pop();
                    int l = id.top(); id.pop();
                    ls[nodeid] = l, rs[nodeid] = r;
                    id.push(nodeid);
                }
                op.push(s[i]);
            }
            else {
                while (op.size() > 0 && op.top() != '(') {
                    c[++nodeid] = op.top(); op.pop();
                    int r = id.top(); id.pop();
                    int l = id.top(); id.pop();
                    ls[nodeid] = l, rs[nodeid] = r;
                    id.push(nodeid);
                }
                op.push(s[i]);
            }
        }
    }
    while (op.size() > 0) {
        c[++nodeid] = op.top(); op.pop();
        int r = id.top(); id.pop();
        int l = id.top(); id.pop();
        ls[nodeid] = l, rs[nodeid] = r;
        id.push(nodeid);
    }
    int rt = id.top();
    cout << dfs(rt) << "\n";
    cout << ans1 << " " << ans2 << "\n";
    return 0;
}