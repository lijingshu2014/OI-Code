#include <bits/stdc++.h>
using namespace std;


inline int read() {
	int out = 0;
	bool flag = false;
	register char cc = getchar();
	while (cc < '0' || cc > '9') {
		if (cc == '-') flag = true;
		cc = getchar();
	}
	while (cc >= '0' && cc <= '9') {
		out = (out << 3) + (out << 1) + (cc ^ 48);
		cc = getchar();
	}
	return flag ? -out : out;
}

inline void write(long long x) {
	if (x < 0) putchar('-'), x = -x;
	if (x == 0) putchar('0');
	else {
		int num = 0;
		char cc[20];
		while (x) cc[++num] = x % 10 + 48, x /= 10;
		while (num) putchar(cc[num--]);
	}
	putchar('\n');
}


int N, x, pos[500010];
long long ans[500010], res;
char s[500010];
vector<int> adj[500010];
int Stack[500010], tot, p[500010];

void dfs(int u, int dep) {
	pos[dep] = u;
	int Last = -1;
	if (s[u] == ')' && tot > 0 && s[pos[Stack[tot]]] == '(') 
		p[u] = Stack[tot], Last = Stack[tot--] - 1;
	else Stack[++tot] = dep;
	
	if (s[u] == ')' && Last != -1) ans[u] = ans[pos[Last]] + 1;
	for (int v : adj[u]) dfs(v, dep + 1);
	if (!p[u]) tot--;
	else Stack[++tot] = p[u], p[u] = 0;
}


void calc(int u) {
	res ^= 1ll * u * ans[u];
	for (int v : adj[u]) ans[v] += ans[u], calc(v);
}

int main() {
	N = read();
	for (int i = 1; i <= N; i++) {
		char ch = getchar();
		while (ch != '(' && ch != ')') ch = getchar();
		s[i] = ch;
	}
	for (int i = 2; i <= N; i++) adj[read()].push_back(i);
	dfs(1, 1);
	calc(1);
	write(res);
	return 0;
}