#include <bits/stdc++.h>

using namespace std;


inline int read() {
	int out = 0; bool flag = false;
	char cc = getchar();
	while (cc < '0' || cc > '9') {
		if (cc == '-') flag = true;
		cc = getchar();
	}
	while (cc >= '0' && cc <= '9') {
		out = (out << 3) + (out << 1) + (cc ^ 48);
		cc = getchar();
	}
	return flag ? -out : out;
}

inline void write(int x, char ch) {
	if (x < 0) putchar('-'), x = -x;
	if (x == 0) putchar('0');
	else {
		int num = 0; char cc[22];
		while (x) cc[++num] = x % 10 + 48, x /= 10;
		while (num) putchar(cc[num--]);
	}
	putchar(ch);
} 

const int L = 1e6 + 10, N = 1e5 + 10;
int len, n, q, id, a[L], stk[N], tp, nodeid, ls[L], rs[L];
char c[L]; bool cge[N], rev[L]; string s;

void dfs(int u) {
	if (c[u] == '&') {
		if ((a[rs[u]] ^ rev[rs[u]]) == 1) {
			if (ls[u] <= n) cge[ls[u]] = true;
			else dfs(ls[u]);
		}
		if ((a[ls[u]] ^ rev[ls[u]]) == 1) {
			if (rs[u] <= n) cge[rs[u]] = true;
			else dfs(rs[u]);
		}
	}
	else {
		if ((a[rs[u]] ^ rev[rs[u]]) == 0) {
			if (ls[u] <= n) cge[ls[u]] = true;
			else dfs(ls[u]);
		}
		if ((a[ls[u]] ^ rev[ls[u]]) == 0) {
			if (rs[u] <= n) cge[rs[u]] = true;
			else dfs(rs[u]);
		}
	}
}

int main() {
    getline(cin, s);
    len = s.size();
	nodeid = n = read();
	for (int i = 1; i <= n; i++) a[i] = read();
	for (int i = 0; i < len; i++) {
		if ('0' <= s[i] && s[i] <= '9') id = id * 10 + s[i] - '0';
		else {
			if (id) stk[++tp] = id, id = 0;
			if (s[i] == '&' || s[i] == '|') {
				c[++nodeid] = s[i];
				int x = stk[tp--], y = stk[tp--];
				a[nodeid] = (s[i] == '&' ? ((a[x] ^ rev[x]) & (a[y] ^ rev[y])) : ((a[x] ^ rev[x]) | (a[y] ^ rev[y])));
				ls[nodeid] = x, rs[nodeid] = y, stk[++tp] = nodeid;
			}
			if (s[i] == '!') rev[stk[tp]] ^= 1;
		}
	}
	dfs(stk[1]);
    for (q = read(); q; q--) write(a[stk[1]] ^ rev[stk[1]] ^ (cge[read()]), '\n');
	return 0;
}

