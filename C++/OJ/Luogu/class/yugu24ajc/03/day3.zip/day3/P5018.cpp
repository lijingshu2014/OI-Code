#include <bits/stdc++.h>
using namespace std;
int N, v[1000010], ans, Max;
int l[1000010], r[1000010], f[1000010];
int read() {
	int tt = 0, fh = 1;
	char cc = getchar();
	while (cc < '0' || cc > '9') {if (cc == '-') fh = -1; cc = getchar();}
	while (cc >= '0' && cc <= '9') tt = tt * 10 + cc - 48, cc = getchar();
	return tt * fh;
}
bool dfs(int a, int b) {
	if (a == -1 && b == -1) return true;
	if (a == -1 || b == -1) return false;
	if (v[a] != v[b]) return false;
	if (!dfs(r[a], l[b])) return false;
	if (!dfs(l[a], r[b])) return false;
	return true;
}
void dfs1(int k) {
	if (k != -1) ans++;
	else return ;
	dfs1(l[k]);
	dfs1(r[k]);
}
int main() {
	//freopen("tree.in", "r", stdin);
	//freopen("tree.out", "w", stdout);
	N = read();
	for (int i = 1; i <= N; i++) {
		v[i] = read();
	}
	for (int i = 1; i <= N; i++) {
		l[i] = read();
		r[i] = read();
	}
	for (int i = 1; i <= N; i++)
		if (dfs(i, i)) {
			ans = 0;
			dfs1(i);
			Max = max(Max, ans);
		}
	cout << Max << endl;
	return 0;
}