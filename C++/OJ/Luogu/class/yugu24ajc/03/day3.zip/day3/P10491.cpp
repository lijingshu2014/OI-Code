#include <bits/stdc++.h>
using namespace std;

const int N = 155;
const int dx[] = {-1, -2, -2, -1, 1, 2, 2, 1};
const int dy[] = {-2, -1, 1, 2, -2, -1, 1, 2};
int n, m, dis[N][N], tx, ty; char s[N][N];
queue<pair<int, int>> q;

int main() {
    memset(dis, 0x3f, sizeof(dis));
    cin >> m >> n;
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++) {
            cin >> s[i][j];
            if (s[i][j] == 'K') dis[i][j] = 0, q.push({i, j});
            if (s[i][j] == 'H') tx = i, ty = j;
        }
    while (!q.empty()) {
        int ux = q.front().first, uy = q.front().second; q.pop();
        for (int i = 0; i < 8; i++) {
            int nx = ux + dx[i], ny = uy + dy[i];
            if (1 <= nx && nx <= n && 1 <= ny && ny <= m && s[nx][ny] != '*' && dis[nx][ny] > dis[ux][uy] + 1) {
                dis[nx][ny] = dis[ux][uy] + 1;
                q.push({nx, ny});
            }
        }
    }
    cout << dis[tx][ty] << '\n';
    return 0;
}

