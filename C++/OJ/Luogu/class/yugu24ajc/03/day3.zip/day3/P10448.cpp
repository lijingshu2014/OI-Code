#include <bits/stdc++.h>
using namespace std;

int n, m, ans[30];
void dfs(int k, int las) {
    if (k == m + 1) {
        for (int i = 1; i <= m; i++) cout << ans[i] << " ";
        cout << "\n";
        return ;
    }
    for (int i = las + 1; i <= n; i++) {
        ans[k] = i;
        dfs(k + 1, i);
        ans[k] = 0;
    }
}

int main() {
    cin >> n >> m;
    dfs(1, 0);
    return 0;
}