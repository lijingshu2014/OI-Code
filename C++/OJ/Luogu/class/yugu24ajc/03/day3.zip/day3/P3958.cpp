#include<bits/stdc++.h>
using namespace std;
inline double dist(const double &x,const double &y,const double &z){
	return sqrt(x*x+y*y+z*z);
}
int T,n,h,r,d,x[1010],y[1010],z[1010];
int m[1010]; vector<int> t[1010];
bool vis[1010],flag;
void dfs(int k){
	vis[k] = true;
	if(z[k] >= h) {
		flag = true;
		return;
	}
	for(int v : t[k])
	    if(!vis[v])
	        dfs(v);
}
int main()
{
	//freopen(".in","r",stdin);
	//freopen(".out","w",stdout);
	cin>>T;
	while(T--){
		memset(vis,false,sizeof(vis));
		memset(m,0,sizeof(m));
		flag=false;
		scanf("%d%d%d",&n,&h,&r);
        for (int i = 1; i <= n; i++) t[i].clear();
		h-=r;
		d=r<<1;
		for(int i=1;i<=n;i++)
		scanf("%d%d%d",&x[i],&y[i],&z[i]);
		for(int i=1;i<n;i++)
			for(int j=i+1;j<=n;j++)
			if(dist((double)(x[i]-x[j]),(double)(y[i]-y[j]),(double)(z[i]-z[j]))<=d)
			{
				t[i].push_back(j);
				t[j].push_back(i);
			}
		for(int i=1;i<=n;i++)
            if(z[i]<=r){
                dfs(i);
                if(flag){
                    puts("Yes");
                    break;
                }
            }
		if(!flag) puts("No");
	}
	return 0;
}

