#include <bits/stdc++.h>
using namespace std;

int T, n, m, p[110][110], res, ans;

void dfs(int k, int s, int d) {
    if (k == n + 1) {
        ans = max(ans, res + s);
        return ;
    }
    if (p[d][k] < p[d + 1][k]) {
        for (int c = 1; c * p[d][k] <= s; c++) {
            res += c * p[d + 1][k];
            dfs(k + 1, s - c * p[d][k], d);
            res -= c * p[d + 1][k];
        }
    }
    dfs(k + 1, s, d);
}

int main() {
    cin >> T >> n >> m;
    for (int i = 1; i <= T; i++)
        for (int j = 1; j <= n; j++) cin >> p[i][j];
    for (int i = 1; i < T; i++) {
        res = 0, ans = m;
        dfs(1, m, i);
        m = ans;
    }
    cout << m << "\n";
    return 0;
}