#include <map>
#include <cstdio>
const int N = 2e6 + 10; int sum[N], cnt[N];
int main()
{
    int n; scanf("%d", &n);
    for (int i = 1, x; i <= n; ++i)
        scanf("%d", &x), sum[i] = sum[i - 1] ^ x;
    cnt[0] = 1; long long ans = 0;
    for (int i = 1; i <= n; ++i) ans += (cnt[sum[i]]++);
    printf("%lld\n", ans); return 0; 
}