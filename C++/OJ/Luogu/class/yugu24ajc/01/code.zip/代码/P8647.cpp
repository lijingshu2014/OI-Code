#include <cstdio>
const int N = 1e5 + 10; typedef long long ll; int h[N], w[N], n;
ll calc(int a)
{
    ll ret = 0;
    for (int i = 1; i <= n; ++i) ret += (ll)(h[i] / a) * (w[i] / a);
    return ret;
}
int main()
{
    int k; scanf("%d%d", &n, &k);
    for (int i = 1; i <= n; ++i) scanf("%d%d", &h[i], &w[i]);
    int l = 1, r = 1e5, mid, ans = -1;
    while (l <= r)
    {
        mid = (l + r) >> 1;
        if (calc(mid) >= k) ans = mid, l = mid + 1;
        else r = mid - 1;
    }
    printf("%d\n", ans); return 0;
}