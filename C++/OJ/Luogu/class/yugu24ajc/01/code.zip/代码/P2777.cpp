#include <cstdio>
#include <algorithm>
const int N = 3e5 + 10; int b[N], c[N];
int main()
{
    int n, mx = 0, cnt = 0; scanf("%d", &n);
    for (int i = 1; i <= n; ++i) scanf("%d", &b[i]), c[i] = b[i];
    std::sort(b + 1, b + n + 1);
    for (int i = 1; i <= n; ++i) 
        b[i] += n - i + 1, mx = std::max(mx, b[i]);
    for (int i = 1; i <= n; ++i) if (c[i] + n >= mx) ++cnt;
    printf("%d\n", cnt); return 0;
}