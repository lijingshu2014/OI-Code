#include <cstdio>
#include <algorithm>
#include <functional>
const int N = 1e5 + 10; int n, vi[N], wi[N], s1[N], s2[N];
bool check(int x)
{
    int t1 = 0, t2 = 0;
    for (int i = 1; i <= n; ++i)
        if (vi[i] >= x) s1[++t1] = vi[i] + wi[i] - x;
        else s2[++t2] = wi[i];
    if (t1 < t2) return false;
    std::sort(s1 + 1, s1 + t1 + 1, std::greater<int>()); 
    std::sort(s2 + 1, s2 + t2 + 1, std::greater<int>());
    for (int i = 1; i <= t2; ++i) if (s1[i] < s2[i]) return false;
    return true;
}
int main()
{
    int qwq; scanf("%d", &qwq);
    while (qwq--)
    {
        scanf("%d", &n);
        for (int i = 1; i <= n; ++i) scanf("%d%d", &vi[i], &wi[i]);
        int l = 0, r = 1e9, mid, ans = 0;
        while (l <= r)
        {
            mid = (l + r) >> 1;
            if (check(mid)) ans = mid, l = mid + 1;
            else r = mid - 1;
        }
        printf("%d\n", ans);
    }
    return 0;
}