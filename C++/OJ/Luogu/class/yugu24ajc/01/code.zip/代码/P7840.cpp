#include <queue>
#include <cstdio>
typedef long long ll; typedef std::pair<ll, int> pii; 
const int N = 3e5 + 10; int d[N], v[N];
int main()
{
    int n; ll ans = 0; scanf("%d", &n);
    // std::priority_queue<pii, std::vector<pii>, std::greater<pii>> pq;  int res = n - 2;
    std::priority_queue<pii> pq; int res = n - 2;
    for (int i = 1; i <= n; ++i)
    {
        scanf("%d", &v[i]), ans += v[i];
        pq.push(pii(-(2 * 1 + 1) * v[i], i)), d[i] = 1;
    }
    while (res--)
    {
        ll x = pq.top().first; int y = pq.top().second; pq.pop();
        ans += -x; ++d[y]; 
        pq.push(pii(-(2 * d[y] + 1) * v[y], y));
    }
    printf("%lld\n", ans); return 0;
}