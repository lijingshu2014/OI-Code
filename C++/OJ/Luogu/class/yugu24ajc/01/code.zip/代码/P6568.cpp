#include <cstdio>
#include <algorithm>
const int N = 1e6 + 10; int a[N];
int main()
{
    int n, k, sum = 0; scanf("%d%d", &n, &k);
    for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
    int r = k + 1, ans = 0;
    for (int i = 1; i <= r; ++i) sum += a[i];
    ans = sum;
    while (r <= n) sum -= a[r - k], sum += a[++r], ans = std::max(ans, sum);
    printf("%d\n", ans); return 0;
}