#include <cstdio>
#include <algorithm>
const int N = 1e3 + 10; int id[N], s[N], a[N], e[N];
// struct A
// {
//     int s, a, e;
// };
// bool cmp(A x, A y)
// {
//     return x.s + x.a + x.e < y.s + y.a + y.e;
// }
bool cmp(int x, int y) 
{ 
    return s[x] + a[x] + e[x] < s[y] + a[y] + e[y]; 
}
int main()
{
    int n; scanf("%d", &n);
    for (int i = 1; i <= n; ++i)
        id[i] = i, scanf("%d%d%d", &s[i], &a[i], &e[i]);
    std::sort(id + 1, id + n + 1, cmp); 
    long long now = 0, sum = 0;
    for (int j = 1, i = id[j]; j <= n; ++j, i = id[j])
    {
        sum += now + s[i] + a[i];
        now += s[i] + a[i] + e[i];
    }
    printf("%lld\n", sum); return 0;
}