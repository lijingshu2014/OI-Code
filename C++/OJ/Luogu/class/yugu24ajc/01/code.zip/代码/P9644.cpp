#include <cstdio>
const int N = 2e5 + 10; int n, k; char s[N], t[N];
bool check(int len)
{
    int cnt = 0;
    for (int i = 1; i <= n; ++i) t[i] = s[i];
    for (int i = 1; i <= n; )
    {
        if (t[i] == '0') { ++i; continue; }
        for (int j = 1; j <= len && i <= n; ++j) t[i++] = '0';
        ++cnt;
    }
    return cnt <= k;
}
int main()
{
    int qwq; scanf("%d", &qwq);
    while (qwq--)
    {
        scanf("%d%d%s", &n, &k, s + 1);
        int l = 1, r = n, mid, ans = -1;
        while (l <= r)
        {
            mid = (l + r) >> 1;
            if (check(mid)) ans = mid, r = mid - 1;
            else l = mid + 1;
        }
        printf("%d\n", ans);
    }
    return 0;
}