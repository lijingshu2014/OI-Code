#include <cstdio>
const int N = 1e5 + 10; int sum[N], cnt[N];
int main()
{
    int n, k; scanf("%d%d", &n, &k);
    for (int i = 1, x; i <= n; ++i)
        scanf("%d", &x), sum[i] = (sum[i - 1] + x) % k; 
    cnt[0] = 1; long long ans = 0;
    for (int i = 1; i <= n; ++i) ans += (cnt[sum[i]]++);
    printf("%lld\n", ans); return 0;
}