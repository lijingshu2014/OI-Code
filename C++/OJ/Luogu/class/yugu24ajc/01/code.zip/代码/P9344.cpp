#include <cstdio>
#include <algorithm>
// #define ll long long 
const int N = 2e6 + 10; typedef long long ll; int a[N], c[N];
int main()
{
    int qwq; scanf("%d", &qwq);
    while (qwq--)
    {
        int n; scanf("%d", &n);
        for (int i = 1; i <= n; ++i) scanf("%d", &a[i]);
        for (int i = 1; i <= n; ++i) scanf("%d", &c[i]);
        if (c[1] == c[n]) printf("%d\n", a[1] + a[n]);
        else
        {
            ll ans = 1e12;
            for (int i = 1; i < n; ++i)
                if (c[i] == c[1] && c[i + 1] == c[n])
                    ans = std::min(ans, (ll)a[1] + a[i] + a[i + 1] + a[n]);
            printf("%lld\n", ans);
        }   
    }
    return 0;
}