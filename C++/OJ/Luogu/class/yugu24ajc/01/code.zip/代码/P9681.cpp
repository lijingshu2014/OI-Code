#include <cstdio>
#include <algorithm>
const int N = 2e5 + 10; typedef long long ll;
int a[N], c[N], sc[N], cnt[N]; ll s[N];
int main()
{
    int n, q; scanf("%d%d", &n, &q);
    for (int i = 1; i <= n; ++i) 
    {
        scanf("%d", &a[i]);
        s[i] = s[i - 1] + a[i];
        cnt[i] = cnt[i - 1] + (a[i] <= 0);
    }
    for (int i = 1; i <= n; ++i)
    {
        if (a[i] <= 0) { sc[i] = sc[i - 1]; continue; }
        int l = 1, r = i, mid, ans = 0;
        while (l <= r)
        {
            mid = (l + r) >> 1;
            if (s[i] - s[mid - 1] > 0 && 
                cnt[i - 1] - cnt[mid - 1] == i - mid)
                ans = mid, r = mid - 1;
            else l = mid + 1;
        }
        c[i] = i - ans + 1; sc[i] = sc[i - 1] + c[i];
    }
    for (int i = 1, l, r; i <= q; ++i)
    {
        scanf("%d%d", &l, &r);
        ll ans = sc[r] - sc[l - 1];
        int L = l, R = r, mid, t = l;
        while (L <= R)
        {
            mid = (L + R) >> 1;
            if (cnt[mid] - cnt[l - 1] < mid - l + 1)   
                t = mid, R = mid - 1;
            else L = mid + 1;
        }
        ans += std::min(t - l + 1, c[t]) - c[t];
        printf("%lld\n", ans);
    }
    return 0;
}