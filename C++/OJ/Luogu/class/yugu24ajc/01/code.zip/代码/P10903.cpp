#include <cstdio>
const int N = 3e5 + 10; int d[N], l[N], r[N], s[2][N];
int main()
{
	int n, m; scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i)
		scanf("%d%d", &l[i], &r[i]), ++d[l[i]], --d[r[i] + 1];
	for (int i = 1; i <= n; ++i) d[i] += d[i - 1];
	for (int i = 1; i <= n; ++i)
		for (int j = 0; j < 2; ++j)
			s[j][i] = s[j][i - 1] + (d[i] == j);
	for (int i = 1; i <= m; ++i)
		printf("%d\n", s[0][l[i] - 1] + s[0][n] - s[0][r[i]] + s[1][r[i]] - s[1][l[i] - 1]);
	return 0;
}