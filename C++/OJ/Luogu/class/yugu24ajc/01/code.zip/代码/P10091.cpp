#include <cmath>
#include <cstdio>
#include <algorithm>
typedef long long ll; typedef long double db; 
const int N = 1e6 + 10; int a[N], b[N], vis[N], n;
ll check(db x)
{
    ll sum = 0; int j = 0;
    for (int i = 1; i <= n; ++i)
    {
        // 计算新的 j
        while (j < n && a[j + 1] < x * b[i]) ++j;
        sum += j;
    }
    return sum;
}
int main()
{
    int q; scanf("%d%d", &n, &q);
    for (int i = 1; i <= n; ++i) scanf("%d", &a[i]),vis[a[i]] = 1;
    for (int i = 1; i <= n; ++i) scanf("%d", &b[i]);
    std::sort(a + 1, a + n + 1); std::sort(b + 1, b + n + 1);
    for (int i = 1; i <= q; ++i)
    {
        ll c; scanf("%lld", &c);
        db l = (db)a[1] / b[n], r = (db)a[n] / b[1], mid;
        while (r - l > 1e-13) // 10^{-13} 
        {
            mid = (l + r) / 2;
            if (check(mid) >= c) r = mid;
            else l = mid;
        }
        for (int j = 1; j <= n; ++j)
        {
            int ta = std::round(l * b[j]); // 四舍五入
            if (ta < N && vis[ta] && fabsl(ta - l * b[j]) < 1e-7)
            {
                int g = std::__gcd(ta, b[j]);
                printf("%d %d\n", ta / g, b[j] / g);
                break;
            }
        }
    }
    return 0;
}