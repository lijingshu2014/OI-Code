#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 5;
int n, m, f[N][3], sum[N], cur[N], ans = -2e9, a[12][N];
int main()
{
    cin >> n >> m;
    if (n <= 2 && m <= 2)
    {
        puts("-1");
        return 0;
    }
    for (int i = 1; i <= n; i++)
        for (int j = 1; j <= m; j++)
            cin >> a[i][j], sum[j] += a[i][j];
    for (int i = 1; i <= m; i++)
        cur[i] = a[1][i] + a[n][i];
    for (int i = 1; i <= m; i++)
    {
        f[i][0] = max(f[i - 1][0], 0) + sum[i]; // 左
        if (i != 1)
        {
            if (i != m)
                f[i][1] = max(f[i - 1][1], f[i - 1][0]) + cur[i]; // 中
            f[i][2] = max(f[i - 1][2], f[i - 1][1]) + sum[i];     // 右
            ans = max(ans, f[i][2]);
        }
    }
    cout << ans << endl;
    return 0;
}
