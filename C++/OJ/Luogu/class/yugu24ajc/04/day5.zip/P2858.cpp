#include <bits/stdc++.h>
using namespace std;
const int N = 2005;
int n, ans, v[N], f[N][N];
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> v[i];
    for (int i = 1; i <= n; i++)
    {
        for (int j = n; j >= i; j--)
        {
            int t = n - (j - i + 1);
            f[i][j] = max(f[i - 1][j] + v[i - 1] * t, f[i][j + 1] + v[j + 1] * t);
        }
    }
    for (int i = 1; i <= n; i++)
        ans = max(ans, f[i][i] + v[i] * n);
    cout << ans << endl;
    return 0;
}