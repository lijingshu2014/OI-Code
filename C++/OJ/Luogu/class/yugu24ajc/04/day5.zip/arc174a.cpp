#include <bits/stdc++.h>
using namespace std;
const int N = 3e5 + 5;
long long n, sum, c, ans, num[N], f[N];
int main()
{
    cin >> n >> c;
    for (int i = 1; i <= n; i++)
    {
        cin >> num[i];
        sum += num[i];
    }
    if (c > 0)
    {
        // 最大子段和
        for (int i = 1; i <= n; i++)
        {
            f[i] = num[i] + max(f[i - 1], 0LL);
            ans = max(ans, f[i]);
        }
    }
    else
    {
        // 最小子段和
        for (int i = 1; i <= n; i++)
        {
            f[i] = num[i] + min(f[i - 1], 0LL);
            ans = min(ans, f[i]);
        }
    }
    cout << sum + (c - 1) * ans;
    return 0;
}