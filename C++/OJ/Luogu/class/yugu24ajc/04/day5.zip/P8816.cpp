#include <bits/stdc++.h>
using namespace std;
const int N = 505;
int n, k, f[N][N], ans;
pair<int, int> p[N];
int main()
{
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
        cin >> p[i].first >> p[i].second;
    sort(p + 1, p + 1 + n);
    for (int i = 1; i <= n; i++)
        for (int j = 0; j <= k; j++)
            f[i][j] = j + 1;
    for (int i = 2; i <= n; i++)
        for (int j = i - 1; j >= 1; j--)
        {
            if (p[j].second > p[i].second)
                continue;
            int dis = p[i].first - p[j].first + p[i].second - p[j].second - 1;
            for (int u = dis; u <= k; u++)
                f[i][u] = max(f[i][u], f[j][u - dis] + dis + 1);
        }
    for (int i = 1; i <= n; i++)
        ans = max(ans, f[i][k]);
    cout << ans << endl;
    return 0;
}