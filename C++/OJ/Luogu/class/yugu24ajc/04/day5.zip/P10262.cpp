#include <bits/stdc++.h>
using namespace std;
const int N = 200;
long long f[N], pre[N], ans;
int p, num;
string s;
int main()
{
    cin >> p >> s;
    int n = s.size();
    for (int i = 0; i < n; i++)
    {
        num = s[i] - '0';
        for (int j = 0; j < p; j++)
            pre[j] = f[j], f[j] = 0;
        for (int j = 0; j < p; j++)
            f[(j * 10 + num) % p] += pre[j];
        f[num % p]++;
        ans += f[0];
    }
    cout << ans << endl;
    return 0;
}