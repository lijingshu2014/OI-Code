#include <bits/stdc++.h>
using namespace std;
const int N = 5005;
int n, f[N];
int main()
{
    cin >> n;
    memset(f, 0x3f3f, sizeof f);
    f[0] = 0;
    for (int i = 1; i <= n; i++)
    {
        if (i >= 3)
            f[i] = min(f[i], f[i - 3] + 1);
        if (i >= 5)
            f[i] = min(f[i], f[i - 5] + 1);
    }
    if (f[n] != f[n + 1])
        cout << f[n] << endl;
    else
        puts("-1");
    return 0;
}