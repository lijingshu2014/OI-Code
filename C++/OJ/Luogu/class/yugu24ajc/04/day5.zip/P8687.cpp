#include <bits/stdc++.h>
using namespace std;
const int N = 105;
int n, m, k;
int f[1 << 20], candy[N];
int main()
{
    cin >> n >> m >> k;
    for (int i = 0; i < n; i++)
        for (int j = 0; j < k; j++)
        {
            int x;
            cin >> x;
            candy[i] |= (1 << x - 1);
        }
    memset(f, 0x3f3f, sizeof(f));
    f[0] = 0;
    for (int i = 0; i < n; i++)
        for (int S = 0; S < 1 << m; S++)
        {
            if (f[S] > N)
                continue;
            f[S | candy[i]] = min(f[S | candy[i]], f[S] + 1);
        }
    if (f[(1 << m) - 1] >= N)
        puts("-1");
    else
        cout << f[(1 << m) - 1] << endl;
    return 0;
}