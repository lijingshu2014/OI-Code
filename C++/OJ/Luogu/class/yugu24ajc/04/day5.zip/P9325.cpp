#include <bits/stdc++.h>
using namespace std;
const int N = 5005;
int n, a[N], f[N][N];
const int inf = 1e9;
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int len = 1; len <= n; len++) // 枚举长度
    {
        int ans = inf;
        for (int l = 1; l + len - 1 <= n; l++) // 枚举左端点
        {
            int r = l + len - 1;
            f[l][r] = f[l + 1][r - 1] + abs(a[l] - a[r]);
            ans = min(ans, f[l][r]);
        }
        printf("%d ", ans);
    }
    return 0;
}