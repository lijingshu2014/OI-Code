#include <bits/stdc++.h>
using namespace std;
const int N = 2e5 + 5;
int n, a, b, c, f[N];
const int mod = 1e9 + 7;
int main()
{
    cin >> n >> a >> b >> c;
    for (int i = 0; i <= n; i++)
    {
        if (i <= c)
            f[i] = 1;
        else
            f[i] = (f[max(i - a, 0)] + f[max(i - b, 0)]) % mod;
    }
    cout << f[n] << endl;
    return 0;
}