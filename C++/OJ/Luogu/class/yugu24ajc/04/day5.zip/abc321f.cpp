#include <bits/stdc++.h>
using namespace std;
const int N = 5005;
const int mod = 998244353;
int Q, k, dp[N];
int main()
{
	cin >> Q >> k;
	dp[0] = 1;
	while (Q--)
	{
		char op = getchar();
		while (op != '+' && op != '-')
			op = getchar();
		int x;
		cin >> x;
		if (op == '+')
		{
			for (int i = k; i >= x; i--)
				dp[i] = (dp[i] + dp[i - x]) % mod;
		}
		else if (op == '-')
		{
			for (int i = x; i <= k; i++)
				dp[i] = (dp[i] - dp[i - x] + mod) % mod;
		}
		cout << dp[k] << endl;
	}
	return 0;
}