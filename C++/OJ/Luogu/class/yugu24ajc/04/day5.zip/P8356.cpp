#include <bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 5;
const int mod = 1e9 + 7;
int n, p, x, y, ans, f[2][N];
signed main()
{
    int T;
    cin >> T;
    while (T--)
    {
        cin >> n >> p >> x >> y;
        ans = 0;
        if (x == y)
        {
            ans = 1;
            for (int i = 1; i <= n; i++)
            {
                if (i * x % p == 0)
                {
                    ans = 0;
                    break;
                }
            }
            cout << ans << endl;
            continue;
        }

        memset(f, 0, sizeof f);
        f[0][0] = 1;
        for (int i = 0; i <= n; i++)
        {
            for (int j = 0; i + j <= n; j++)
            {
                if (i == 0 && j == 0)
                    continue;
                if ((i * x + j * y) % p == 0)
                {
                    f[i & 1][j] = 0;
                }
                else
                {
                    if (i == 0)
                        f[i & 1][j] = f[i & 1][j - 1];
                    if (j == 0)
                        f[i & 1][j] = f[i & 1 ^ 1][j];
                    if (i > 0 && j > 0)
                        f[i & 1][j] = (f[i & 1 ^ 1][j] + f[i & 1][j - 1]) % mod;
                }
                if (i + j == n)
                {
                    ans = (ans + f[i & 1][j]) % mod;
                }
            }
        }
        cout << ans << endl;
    }
    return 0;
}
