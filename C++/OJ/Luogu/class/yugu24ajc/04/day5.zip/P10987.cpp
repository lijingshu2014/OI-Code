#include <bits/stdc++.h>
using namespace std;
const int N = 1005;
int n, a, b, ans, w[N], f[N][N];
int main()
{
	cin >> n >> a >> b;
	for (int i = 1; i <= n; i++)
	{
		cin >> w[i];
		for (int j = a; j >= 0; j--)
			for (int k = b; k >= 0; k--)
			{
				if (j >= w[i])
					f[j][k] = max(f[j][k], f[j - w[i]][k] + w[i]);
				if (k >= w[i])
					f[j][k] = max(f[j][k], f[j][k - w[i]] + w[i]);
				ans = max(ans, f[j][k]);
			}
	}
	cout << ans << endl;
	return 0;
}