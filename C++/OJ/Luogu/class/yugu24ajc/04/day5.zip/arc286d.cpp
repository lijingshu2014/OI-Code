#include <bits/stdc++.h>
using namespace std;
const int N = 1e4+5;
int n,m,f[N];
int main(){
    cin>>n>>m;
    f[0]=1;
    while (n --)
    {
        int a,b;
        scanf ("%d%d", &a, &b);
        while (b --) // 拆成bi件物品
        {
            for (int i = m; i >= a; i --) // 倒序循环
            {
                f[i] |= f[i - a];
            }
        }
    }
    if(f[m])puts("Yes");
    else puts("No");
    return 0;
}