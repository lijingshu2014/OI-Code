#include <bits/stdc++.h>
using namespace std;

int n, m, q, a[1010][1010];
const int fx[4] = {0, 1, 0, -1};
const int fy[4] = {1, 0, -1, 0};
int dis[1010][1010];
void bfs(){
    queue<pair<int, int>> q;
    memset(dis, 63, sizeof(dis));
    q.push({1, 1}); dis[1][1] = 0;
    while(!q.empty()){
        int x = q.front().first, y = q.front().second;
        q.pop();
        for(int dir = 0; dir < 4; dir ++){
            int xx = x + fx[dir], yy = y + fy[dir];
            if(xx < 1 || xx > n || yy < 1 || yy > n || a[xx][yy] == 0) continue;
            if(dis[xx][yy] > dis[x][y] + 1){
                dis[xx][yy] = dis[x][y] + 1;
                q.push({xx, yy});
            }
        }
    }
}
int st[21][1000010], log_2[1000010];
void st_init(){
    int mdis = 0;
    for(int i = 1; i <= n; i ++)
        for(int j = 1; j <= m; j ++)
            if(a[i][j] > 0 && dis[i][j] < n * m){
                mdis = max(mdis, dis[i][j]);
                st[0][dis[i][j]] = max(st[0][dis[i][j]], a[i][j]);
            }
    for(int j = 1; j <= 20; j ++)
        for(int i = 0; i + (1 << j) - 1 <= mdis; i ++)
            st[j][i] = max(st[j - 1][i], st[j - 1][i + (1 << j - 1)]);
    for(int i = 2; i <= mdis; i ++)
        log_2[i] = log_2[i >> 1] + 1;
}

int main()
{
    scanf("%d %d %d", &n, &m, &q);
    for(int i = 1; i <= n; i ++)
        for(int j = 1; j <= m; j ++)
            scanf("%d", &a[i][j]);
    bfs();
    st_init();
    for(int i = 1; i <= q; i ++){
        int l, r; scanf("%d %d", &l, &r);
        int p = log_2[r - l + 1];
        int ans = max(st[p][l], st[p][r - (1 << p) + 1]);
        if (ans <= 0) ans = 0;
        printf("%d\n", ans);
    }
}