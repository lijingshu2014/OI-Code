#include <bits/stdc++.h>
using namespace std;
#define MAXN 200010

int n, q, a[MAXN];
vector<int> to[MAXN];
int f[20][MAXN], dep[MAXN];
int s[MAXN][30];
void dfs(int x){
    dep[x] = dep[f[0][x]] + 1;
    for(int i = 0; i < 30; i ++)
        s[x][i] = s[f[0][x]][i] + (a[x] >> i & 1);
    for(int y : to[x]){
        if(y == f[0][x]) continue;
        f[0][y] = x;
        dfs(y);
    }
}
int get_lca(int x, int y){
    if(dep[x] > dep[y]) swap(x, y);
    for(int j = 18; j >= 0; j --)
        if(dep[f[j][y]] >= dep[x])
            y = f[j][y];
    if(x == y) return x;
    for(int j = 18; j >= 0; j --)
        if(f[j][x] != f[j][y])
            x = f[j][x], y = f[j][y];
    return f[0][x];
}

int main()
{
    ios::sync_with_stdio(false); cin.tie(0);
    cin >> n >> q;
    for(int i = 1; i <= n; i ++) cin >> a[i];
    for(int i = 1; i < n; i ++){
        int x, y; cin >> x >> y;
        to[x].push_back(y);
        to[y].push_back(x);
    }
    dfs(1);
    for(int j = 1; j <= 18; j ++)
        for(int i = 1; i <= n; i ++)
            f[j][i] = f[j - 1][f[j - 1][i]];
    for(int i = 1; i <= q; i ++){
        int x, y; cin >> x >> y;
        int ans = 0, lca = get_lca(x, y);
        for(int j = 0; j < 30; j ++){
            int tot = s[x][j] + s[y][j] - s[lca][j] - s[f[0][lca]][j];
            int len = dep[x] + dep[y] - 2 * dep[lca] + 1;
            if(tot > 0) ans += (1 << j);
            if(tot == len) ans -= (1 << j);
        }
        cout << ans << '\n';
    }
}