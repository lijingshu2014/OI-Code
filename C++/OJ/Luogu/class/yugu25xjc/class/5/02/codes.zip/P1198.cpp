#include <bits/stdc++.h>
using namespace std;

const int MAXN = 200000 + 7;
const int LOG = 20;

int T, mod, n, lst;
int st[MAXN][LOG];

const double lg2 = log(2);

int main() {
    cin >> T >> mod;
    memset(st, -1, sizeof(st));
    while(T--) {
        char op; int x;
        cin >> op >> x;
        if(op == 'Q') {
            int k = (int)((log((double)x)) / lg2);
            int l = n - x + 1, r = n;
            int ans = max(st[l][k], st[r - (1 << k) + 1][k]);
            lst = ans;
            cout << ans << '\n';
        } else {
            int val = (1ll * lst + x) % mod;
            ++n; st[n][0] = val;
            for(int i = 1; i < LOG && 1 << i <= n; i++) {
                st[n - (1 << i) + 1][i] = max(st[n - (1 << i) + 1][i - 1], st[n - (1 << i) + 1 + (1 << (i - 1))][i - 1]);
            }
        }
    }
}