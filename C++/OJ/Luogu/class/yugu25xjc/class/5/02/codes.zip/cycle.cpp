#include<bits/stdc++.h>
using namespace std;

int n, m, k, x;

int fpow(long long x, int p) {
    long long ret = 1;
    while(p) {
        if(p & 1) ret = ret * x % n;
        x = x * x % n; p >>= 1;
    }
    return ret;
}

int main() {
    cin >> n >> m >> k >> x;
    int step = fpow(10, k);
    int ans = (x + step) % n;
    cout << ans << endl;
    return 0;
}