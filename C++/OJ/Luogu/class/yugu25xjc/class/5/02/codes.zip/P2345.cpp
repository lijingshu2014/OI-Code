#include <bits/stdc++.h>
using namespace std;

const int MAXN = 50000 + 7;

struct Info {
    int x, v;
}a[MAXN], b[MAXN];

int n;
long long ans;

void f(int l, int r) {
    if(l == r) return;
    int mid = (l + r) / 2;
    f(l, mid); f(mid + 1, r);
    int pl = l, pr = mid + 1, p = l, cnt = 0;
    long long sum = 0, rest = 0;
    for(int i = l; i <= mid; i++) rest += a[i].x;
    while(p <= r) {
        if(pl > mid || (pr <= r && a[pl].x > a[pr].x)) {
            ans += 1ll * a[pr].v * (1ll * cnt * a[pr].x - sum);
            ans += 1ll * a[pr].v * (rest - 1ll * (mid - l + 1 - cnt) * a[pr].x);
            b[p] = a[pr];
            pr++; p++;
            continue;
        }
        else {
            cnt++; sum += a[pl].x; rest -= a[pl].x;
            b[p] = a[pl];
            pl++; p++;
            continue;
        }
    }
    memcpy(a + l, b + l, sizeof(Info) * (r - l + 1));
}

int main() {
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> a[i].v >> a[i].x;
    }
    sort(a + 1, a + n + 1, [](Info a, Info b) -> bool {return a.v < b.v;});
    f(1, n);
    cout << ans << endl;
    return 0;
}