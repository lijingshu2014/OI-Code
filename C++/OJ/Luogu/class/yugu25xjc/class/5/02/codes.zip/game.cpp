#include<bits/stdc++.h>
using namespace std;

typedef unsigned long long ull;

int T;

bool count(ull x) {
    int cnt = 0;
    while(x) {
        if(x & 1 == 1) ++cnt;
        x >>= 1;
    }
    return cnt;
}

int main() {
    cin >> T;
    while(T--) {
        ull x; cin >> x;
        int cnt = count(x);
        if(cnt > 2) {
            cout << "Nooooo" << endl;
            continue;
        }
        if(cnt <= 1) {
            cout << x + 1 << endl;
            continue;
        }
        for(int j = 0; j < 63; j++) {
            if((x >> j) & 1 == 1) {
                cout << x + (1ull << j) << endl;
                break;
            }
        }
    }
}