#include<bits/stdc++.h>
using namespace std;

unsigned long long a, b;

int main() {
    cin >> a >> b;

    cout << a * (1ull << b) << endl;

    cout << (a >> b) << endl;
    
    cout << ((a >> b) & 1ull) << endl;

    unsigned long long mask4 = 0xffffffffffffffff ^ (1ull << b);
    cout << (a & mask4) << endl;

    unsigned long long mask5 = 1ull << b;
    cout << (a | mask5) << endl;

    unsigned long long mask6 = 1ull << b;
    cout << (a ^ mask6) << endl;
}