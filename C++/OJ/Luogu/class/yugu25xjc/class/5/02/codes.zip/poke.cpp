#include<bits/stdc++.h>
using namespace std;

int n, ans;

int main() {
    cin >> n;
    for(int i = 1, v, t; i <= n; i++) {
        cin >> v >> t;
        for(int j = 1; j <= t; j++) {
            ans ^= v * j;
        }
    }
    cout << ans << endl;
}