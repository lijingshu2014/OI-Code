#include <bits/stdc++.h>
using namespace std;

long long n;

unordered_map <long long, long long> mp;

long long f(long long len) {
    if(len <= 4) return 0;
    if(mp.find(len) != mp.end()) return mp[len];
    if(len % 2 == 0) return mp[len] = f(len / 2) + f(len / 2 + 1) + 1;
    return mp[len] = 2 * f(len / 2 + 1) + 1;
}

int main() {
    cin >> n;
    if(n <= 2) cout << 1 << endl;
    else cout << f(n) + 2 << endl;
    return 0;
}