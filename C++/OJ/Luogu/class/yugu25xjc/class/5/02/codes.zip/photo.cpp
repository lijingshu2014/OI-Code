#include <bits/stdc++.h>
using namespace std;

int c[100010], tot;
void add(int x){
    c[x] ++;
    if(c[x] == 1) tot ++;
}
void del(int x){
    c[x] --;
    if(c[x] == 0) tot --;
}
void Solve(){
    int n; cin >> n;
    vector<int> a(2 * n);
    for(int i = 0; i < 2 * n; i ++)
        cin >> a[i];
    for(int i = 1; i <= n; i ++) c[i] = 0;
    tot = 0;
    bool ans = false;
    for(int l = 0, r = -1; r + 1 < 2 * n; l ++){
        while(r - l + 1 < n){
            r ++;
            add(a[r]);
        }
        if(tot == n) ans = true;
        del(a[l]);
    }
    if(ans) cout << "Yes\n";
    else cout << "No\n";
}

int main()
{
    ios::sync_with_stdio(false); cin.tie(0);
    int T; cin >> T;
    while(T --) Solve();
}