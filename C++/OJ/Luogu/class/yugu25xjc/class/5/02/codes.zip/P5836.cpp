#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;
const int LOG = 19;

int n, T;

bool h[MAXN][LOG], g[MAXN][LOG];
int fa[MAXN][LOG], dep[MAXN];
vector <int> G[MAXN];
char S[MAXN];

void dfs(int x, int f) {
    fa[x][0] = f, dep[x] = dep[f] + 1;
    h[x][0] = S[x] == 'H';
    g[x][0] = S[x] == 'G';
    for(int i = 1; i < LOG; i++) {
        fa[x][i] = fa[fa[x][i - 1]][i - 1];
        h[x][i] = h[x][i - 1] | h[fa[x][i - 1]][i - 1];
        g[x][i] = g[x][i - 1] | g[fa[x][i - 1]][i - 1];
    }
    for(auto v: G[x]) {
        if(v == f) continue;
        dfs(v, x);
    }
}

bool solve(int x, int y, char op) {
    if(dep[x] < dep[y]) swap(x, y);
    bool hr = false, gr = false;
    for(int i = LOG - 1; i >= 0; i--) {
        if(dep[x] - dep[y] >= (1 << i)) {
            hr |= h[x][i], gr |= g[x][i];
            x = fa[x][i];
        }
    }
    if(x == y) return (op == 'H'? hr | h[x][0]: gr | g[x][0]);
    for(int i = LOG - 1; i >= 0; i--) {
        if(fa[x][i] != fa[y][i]) {
            hr |= h[x][i] | h[y][i], gr |= g[x][i] | g[y][i];
            x = fa[x][i], y = fa[y][i];
        }
    }
    hr |= h[x][1] | h[y][1], gr |= g[x][1] | g[y][1];
    return (op == 'H'? hr: gr);
}

int main() {
    cin >> n >> T;
    cin >> (S + 1);
    for(int i = 1, x, y; i < n; i++) {
        cin >> x >> y;
        G[x].push_back(y);
        G[y].push_back(x);
    }
    dfs(1, 0);
    while(T--) {
        int x, y; char op;
        cin >> x >> y >> op;
        bool ans = solve(x, y, op);
        cout << (ans ? '1': '0');
    }
}