#include <bits/stdc++.h>
using namespace std;

int main(int argc, char *argv[])
{
    if(argc == 3){
        freopen(argv[1], "r", stdin);
        freopen(argv[2], "w", stdout);
    }
    int n, q1, q2; scanf("%d %d %d", &n, &q1, &q2);
    vector<long long> a(n + 2);
    for(int i = 1; i <= n; i ++)
        scanf("%d", &a[i]);
    
    for(int i = n; i >= 2; i --)
        a[i] -= a[i - 1];
    for(int i = 1; i <= q1; i ++){
        int l, r, c; scanf("%d %d %d", &l, &r, &c);
        a[l] += c; a[r + 1] -= c;
    }
    for(int i = 2; i <= n; i ++)
        a[i] += a[i - 1];
    
    for(int i = 2; i <= n; i ++)
        a[i] += a[i - 1];
    for(int i = 1; i <= q2; i ++){
        int l, r; scanf("%d %d", &l, &r);
        printf("%lld\n", a[r] - a[l - 1]);
    }
}