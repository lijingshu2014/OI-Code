#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;
const int LOG = 18;

typedef pair<int, int> Edge;

vector <Edge> G[MAXN];
int n, T;

int fa[MAXN][LOG], w[MAXN][LOG];
int dep[MAXN];

void dfs(int x, int f, int val) {
    dep[x] = dep[f] + 1;
    fa[x][0] = f, w[x][0] = val;
    for(int i = 1; i < LOG; i++) {
        fa[x][i] = fa[fa[x][i - 1]][i - 1];
        w[x][i] = w[x][i - 1] ^ w[fa[x][i - 1]][i - 1];
    }
    for(auto [v, w]: G[x]) {
        if(v == f) continue;
        dfs(v, x, w);
    }
}

int solve(int x, int y) {
    int ans = 0;
    if(dep[x] < dep[y]) swap(x, y);
    for(int i = LOG - 1; i >= 0; i--) {
        if(dep[x] + (1 << i) <= dep[y]) {
            ans ^= w[x][i];
            x = fa[x][i];
        }
    }
    if(x == y) return ans;
    for(int i = LOG - 1; i >= 0; i--) {
        if(fa[x][i] != fa[y][i]) {
            ans ^= w[x][i] ^ w[y][i];
            x = fa[x][i], y = fa[y][i];
        }
    }
    return ans ^ w[x][0] ^ w[y][0];
}

int main() {
    cin >> n;
    for(int i = 1, x, y, z; i < n; i++) {
        cin >> x >> y >> z;
        G[x].push_back({y, z});
        G[y].push_back({x, z});
    }
    dfs(1, 0, 0);
    cin >> T;
    while(T--) {
        int x, y; cin >> x >> y;
        int ans = solve(x, y);
        cout << ans << '\n';
    }
    return 0;
}