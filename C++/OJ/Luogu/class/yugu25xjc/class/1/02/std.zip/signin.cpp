#include<bits/stdc++.h>
using namespace std;

int ans, n, x, raw, day;

int credit(int x) {
    if(x <= 2) return 1;
    else if(x <= 6) return 2;
    else if(x <= 29) return 3;
    else if(x <= 119) return 4;
    else if(x <= 364) return 5;
    return 6;
}

int main() {
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> x;
        if(x == 1) {
            if(raw > 0) day = max(0, day - (1 << (raw - 1)));
            // raw 999 1<<998 
            // 1 << x = 2^x 
            day++;
            raw = 0;
            ans += credit(day);
        }
        else {
            raw++;
        }
    }
    cout << ans << endl;
}
