#include<bits/stdc++.h>
using namespace std;

int a[107][107][57], top[107][107];
int n, m, k, t;

int main() {
	cin >> n >> m >> k >> t;
	while(t--) {
		int id, x, y;
		cin >> id >> x >> y;
		if(top[x][y] != k) {
			++top[x][y];
			a[x][y][top[x][y]] = id;
			cout << -1 << endl;
		}
		else {
			int pos = 0, minval = 1000000000;
			for(int i = 1; i <= k; i++) {
				if(a[x][y][i] <= minval) {
					pos = i, minval = a[x][y][i];
				}
			}
			cout << minval << ' ' << k - pos << endl;
			for(int i = pos; i < k; i++) {
				a[x][y][i] = a[x][y][i + 1];
			}
			a[x][y][k] = id;
		}
	}
}