#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;

int n, e[MAXN];
char s[MAXN];

int H1 = -1, G1 = -1;
int Hr, Gr, H, G;

int main() {
    cin >> n; H = G = n;
    cin >> (s + 1);
    for(int i = 1; i <= n; i++) {
        cin >> e[i];
        if(s[i] == 'H') Hr = max(Hr, i), H = min(H, i);
        else Gr = max(Gr, i), G = min(G, i);
    }
    if(e[H] >= Hr) H1 = H;
    if(e[G] >= Gr) G1 = G;
    // cout << H1 << ' ' <<G1;
    long long ans = 0;
    for(int i = 1; i <= n; i++) {
        if(s[i] == 'H') {
            if((G1 != -1 && e[i] >= G1 && i <= G1) || i == H1) {
                // cout << i << endl;
                ans++;
            }
        }
        else {
            if((H1 != -1 && e[i] >= H1 && i <= H1) || i == G1) {
                ans++;
                // cout << i << endl;
            }
        }
    }
    cout << ans - 1 << '\n';
    return 0;
}