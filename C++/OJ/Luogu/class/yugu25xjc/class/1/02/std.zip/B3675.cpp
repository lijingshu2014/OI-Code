#include<bits/stdc++.h>
using namespace std;

const int maxn = 1000 + 7;

int n, m;
int a[maxn][maxn], b[maxn][maxn];
double val[maxn];

vector <int> vx, vy;

int main(void) {
	scanf("%d%d", &m, &n);
	for(int i = 1; i <= n; i++) {
		double S = 0; double aval = 0.0;
		for(int j = 1; j <= m; j++) {
			scanf("%d", &a[i][j]);
			S += (double)a[i][j];
		}
		S /= (double)m;
		for(int j = 1; j <= m; j++) {
			aval += ((double)a[i][j] - S) * ((double)a[i][j] - S);
		}
		aval /= (double)m;
		val[i] += aval;
	}
	for(int i = 1; i <= n; i++) {
		double S = 0; double bval = 0.0;
		for(int j = 1; j <= m; j++) {
			scanf("%d", &b[i][j]);
			S += (double)b[i][j];
		}
		S /= (double)m;
		for(int j = 1; j <= m; j++) {
			bval += ((double)b[i][j] - S) * ((double)b[i][j] - S);
		}
		bval /= (double)m;
		val[i] += bval;
	}
	for(int i = 1; i <= n; i++) {
		for(int j = 1; j < i; j++) {
			if(val[j] > val[i]) {
				vx.push_back(i); vy.push_back(j);
				swap(val[i], val[j]);
			}
		}
	}
	printf("%d\n", (int)vx.size());
	for(int i = 0; i < (int)vx.size(); i++) {
		printf("%d %d\n", vx[i], vy[i]);
	}
	return 0;
}