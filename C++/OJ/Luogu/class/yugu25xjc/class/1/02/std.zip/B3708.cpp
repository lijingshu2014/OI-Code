#include<bits/stdc++.h>
using namespace std;

int n, k;
int a[10];

int main() {
	cin >> n >> k;
	//10^{n-1} // 10^n - 1
	int st = 1, ed = 1;
	for(int i = 1; i < n; i++) st *= 10;
	for(int i = 1; i <= n; i++) ed *= 10;
	--ed;
	for(int i = st; i <= ed; i++) {
		a[i % k]++;
	}
	for(int i = 0; i < k; i++) {
		printf("%d ", a[i]);
	}
}