#include<bits/stdc++.h>
using namespace std;

const int MAXR = 500 + 7;
char s[MAXR][MAXR];
int n, m, r, c, ans;

int main() {
	scanf("%d%d%d%d", &r, &c, &n, &m);
	for(int i = 1; i <= r; i++) {
		scanf("%s", s[i] + 1);
	}
	for(int i = 1; i <= r; i++) {
		for(int j = 1; j <= c; j++) {
			if(s[i][j] == '.') continue;
			bool ok = true;
			// (i,j)
			int cnt = 0;
			// (?,j)
			for(int k = 1; k < i; k++) {
				if(s[k][j] != '.' && s[k][j] != s[i][j]) {
					ok = false; break;
				}
			}
			if(ok) ++cnt;
			ok = true;
			for(int k = i + 1; k <= r; k++) {
				if(s[k][j] != '.' && s[k][j] != s[i][j]) {
					ok = false; break;
				}
			}
			// (?,j)
			if(ok) ++cnt;
			ok = true;
			for(int k = 1; k < j; k++) {
				if(s[i][k] != '.' && s[i][k] != s[i][j]) {
					ok = false; break;
				}
			}
			//(i,?)
			if(ok) ++cnt;
			ok = true;
			for(int k = j + 1; k <= c; k++) {
				if(s[i][k] != '.' && s[i][k] != s[i][j]) {
					ok = false; break;
				}
			}
			if(ok) ++cnt;
			if(cnt >= 3) ++ans;
		}
	}
	printf("%d\n", ans);
	return 0;
}
