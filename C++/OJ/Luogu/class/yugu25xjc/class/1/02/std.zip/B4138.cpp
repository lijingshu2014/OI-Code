#include<bits/stdc++.h>
using namespace std;

const int MAXN = 1000 + 7;

int a[MAXN], b[MAXN];

int main() {
    int n, k, q;
    cin >> n >> k >> q;
    for(int i = 1; i <= n; i++) {
        a[i] = i;
    }
    while(k--) {
        for(int i = 1; i <= n; i++) {
        	if(i % 2 == 1) {
        		b[i] = a[(i + 1) / 2];
			}
			else b[i] = a[(i + n) / 2];
//            b[i] = a[(i + 1) / 2 + ((i + 1) % 2) * n / 2];
        }
        memcpy(a, b, sizeof(a));
        // memcpy(dst, src, size);
    }
    cout << a[q] << endl;
    return 0;
}
