#include<bits/stdc++.h>
using namespace std;

int main() {
    int n, m, a, b, ans = 0;
    cin >> n >> m >> a >> b;
    for(int i = 1; i <= m; i++) {
        int x; cin >> x;
        int expa = -1, expb = -1;
        for(int j = 1, w; j <= x; j++) {
            cin >> w;
            if(w == a) expa = j;
            if(w == b) expb = j;
        }
        if(expa != -1 && expb != -1 && expa < expb) ans++;
    }
    cout << ans << endl;
    return 0;
}