#include<bits/stdc++.h>
using namespace std;

const int MAXN = 30 + 7;

char s[MAXN][MAXN];
int n;

int dx[] = {-1, -1, -1, 0, 0, 1, 1, 1};
int dy[] = {-1, 0, 1, -1, 1, -1, 0, 1};

bool valid(int x, int y) {
    if(x >= 1 && x <= n && y >= 1 && y <= n) return true;
    return false;
}

int main() {
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> (s[i] + 1);
    }
    for(int i = 1; i <= n; i++) {
        for(int j = 1; j <= n; j++) {
            for(int k = 0; k < 8; k++) {
                int nx1 = i + dx[k], ny1 = j + dy[k];
                int nx2 = i - dx[k], ny2 = j - dy[k];
                if(valid(nx1, ny1) && valid(nx2, ny2) && s[nx1][ny1] == s[nx2][ny2] && s[nx1][ny1] == s[i][j] && s[i][j] != '.') {
                    cout << s[i][j] << endl;
                    return 0;
                }
            }
        }
    }
    cout << "ongoing" << endl;
    return 0;
}