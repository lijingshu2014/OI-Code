#include<bits/stdc++.h>
using namespace std;

const int MAXN = 200000 + 7;
int val[10] = {1, 0, 0, 0, 1, 0, 1, 0, 2, 1};

//a[i] 1~n a[i] represent ith number
// val[i] i feng bi tu xing shumu 

int n;

struct Info {
    int x, v;
}a[MAXN];

int calc(int x) {
    int ret = 0;
    while(x) {
        ret += val[x % 10];
        x /= 10;
    }
    return ret;
}

bool cmp(Info a, Info b) {
	if(a.v == b.v) return a.x < b.x;
	return a.v < b.v;
}

int main() {
    cin >> n;
    for(int i = 1; i <= n; i++) {
        cin >> a[i].x;
        a[i].v = calc(a[i].x);
    }
    sort(a + 1, a + n + 1, cmp);
    for(int i = 1; i <= n; i++) {
        cout << a[i].x << ' ';
    }
    return 0;
}
