#include<bits/stdc++.h>
using namespace std;

const int MAXN = 5000 + 7;
int n, k, a[MAXN], ans;

int main() {
    cin >> n >> k;
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for(int i = 1; i + k - 1 <= n; i++) {
        int win = 0;
        for(int j = i; j <= i + k - 1; j++) { // [l, l + k - 1] k matches 
            a[j] -= 2;
        }
        for(int j = 1; j <= n; j++) {
            if(99 - a[j] > a[j]) ++win;
            // printf("[i=%d] a[%d]=%d\t", i, j, a[j]);
        }
        if(win > n / 2) {
            ans++;
            // printf("[%d] WINS [%d]", i, win);
        }
        for(int j = i; j <= i + k - 1; j++) {
            a[j]+= 2;
        }
        
        // [l, l+k-1]
        // [l+1, l+k]
        // a[l]
        // a[l+k]
        
        // printf("\n");
    }
    cout << ans << endl;
}
