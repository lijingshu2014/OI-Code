#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100000 + 7;
int c[MAXN], n;

int main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> c[i];
	}
	sort(c + 1, c + n + 1, [](const int &a, const int &b){return a > b;});
	long long mx = -1, fee = -1;
	for(int i = 1; i <= n; i++) {
		long long val = 1ll * c[i] * i;
		if(mx == val) {
			fee = c[i];
		}
		else if(mx < val) {
			mx = val; fee = c[i];
		}
	}
	cout << mx << ' ' << fee << endl;
}
