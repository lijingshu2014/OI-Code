#include<bits/stdc++.h>
using namespace std;

const int MAXN = 100 + 7;

ll n, t, p[MAXN], f[MAXN], m;
string s[MAXN];
bool y[MAXN][MAXN];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(NULL) , cout.tie(NULL);
	cin >> t;
	while ( t-- )
	{
		cin >> m >> n;
		bool e = true;
		vector <int> flag(n + 1), k(n + 1);
		for ( int i = 1; i <= n; i++ )	cin >> s[i] >> p[i] , flag[i] = 0;
		for ( int j = 1; j <= m; j++ )
			for ( int l = 0; l < m; l++ )
			{
				int k[2] = { 0 , 0 } , buck[2] = { 2 , 2 };
				for ( int i = 1; i <= n; i++ )
				{
					y[i][l] = ( s[i][l] == '1' );
					if ( flag[i] )	continue;
					if ( buck[y[i][l]] == 2 )	buck[y[i][l]] = p[i];
					else	if ( buck[y[i][l]] != p[i] )	k[y[i][l]] = 1;
				}
				for ( int i = 1; i <= n; i++ )	if ( !k[y[i][l]] )	flag[i] = 1;
			}
		for ( int i = 1; i <= n; i++ )	if ( !flag[i] )	e = 0;
		if ( e )	cout << "OK" << endl;
		else	cout << "LIE" << endl;
	}
	return 0;
}

