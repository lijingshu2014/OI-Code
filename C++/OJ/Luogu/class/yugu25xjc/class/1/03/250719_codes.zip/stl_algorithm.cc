#include <bits/stdc++.h>

int main() {
  int a = 3, b = 5, c = 14, d = 4;
  std::cout << std::max({a, b, c, d}) << '\n';
  std::swap(a, b);
  std::cout << a << ' ' << b << '\n';
  std::vector<int> v(4);
  v[0] = 4; v[1] = 3; v[2] = 3; v[3] = 2;
  std::nth_element(v.begin(), v.begin() + 2, v.end());
  std::sort(v.begin(), v.end());
  v.erase(std::unique(v.begin(), v.end()), v.end());
  for (auto i : v) std::cout << i << '\n';
  v.clear();
  v.push_back(0);
  v.push_back(1);
  v.push_back(3);
  v.push_back(3);
  v.push_back(3);
  v.push_back(6);
  v.push_back(7);
  //0, 1, 3, 3, 3,6,7
  std::cout << *std::lower_bound(v.begin(), v.end(), 3) << '\n';
  std::cout << *std::upper_bound(v.begin(), v.end(), 3) << '\n';
  auto [l, r] = std::equal_range(v.begin(), v.end(), 3);
  std::cout << l - v.begin() << ' ' << r - v.begin() << '\n';
  std::vector<int> p(4);
  for (int i = 0; i < 4; ++i) p[i] = i;
  do {
    for (auto i : p) std::cout << i << ' ';
    std::cout << '\n';
  } while (std::next_permutation(p.begin(), p.end()));
}