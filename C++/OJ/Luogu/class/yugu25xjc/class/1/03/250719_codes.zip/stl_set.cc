#include <set>
#include <iostream>

int main() {
  std::set<int> s;
  s.insert(7);
  s.insert(4);
  s.insert(5);
  s.insert(4);
 // s.erase(5);
  for (auto i : s) std::cout << i << '\n';
  std::cout << *s.lower_bound(5) << '\n';
  std::cout << *s.upper_bound(5) << '\n';
  std::cout << '\n';
  if (s.find(6) != s.end()) {
    std::cout << "6 in set";
  } else {
    std::cout << "6 not in set";
  }
  std::multiset<int> ms;
  ms.insert(4);
  ms.insert(5);
  ms.insert(4);
  ms.insert(4);
  ms.erase(ms.find(4));
  for (auto i : ms) std::cout << i << '\n';
}