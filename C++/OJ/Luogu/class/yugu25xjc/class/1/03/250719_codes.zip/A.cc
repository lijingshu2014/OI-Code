#include <bits/stdc++.h>

struct A {
  int x, y;
  A(int u = 0, int v = 0) {
    x = u;
    y = v;
  }
};

int a[100];

A* generate_A(int u, int v) {
  auto ret = new A(u, v);
  return ret;
}

int f() {
  int a, b;
  return 0;
}

int main() {
  std::vector<int> a(10);
  *a.begin() = 1;
  *(a.begin() + 5) = 5;
  auto p = a.begin();
  ++p;
  *p = 4;
  std::cout << a[1] << '\n';
}