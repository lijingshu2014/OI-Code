#include <bits/stdc++.h>

int main() {
  int n = 5;
  std::vector<int> a(n);
  for (auto &i : a) std::cin >> i;
  for (auto i : a) std::cout << i << '\n';
  for (auto i = a.begin(); i != a.end(); ++i)
    std::cout << *i;

}