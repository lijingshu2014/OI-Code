#include <deque>
#include <iostream>

void printQueue(const std::deque<int> Q) {
  for (auto i : Q) std::cout << i << ' ';
  std::cout << '\n';
}

int main() {
  std::deque<int> Q;
  Q.push_back(1);
  Q.push_back(2);
  Q.push_back(3);
  printQueue(Q);
  Q.pop_back();
  printQueue(Q);
  Q.push_front(4);
  printQueue(Q);
  Q.push_front(5);
  Q.push_front(5);
  Q.pop_front();
  printQueue(Q);
}