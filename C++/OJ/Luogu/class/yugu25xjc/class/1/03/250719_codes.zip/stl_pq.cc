#include <bits/stdc++.h>

struct A {
  int x;
  
  inline bool operator<(const A &o) const {
    return x > o.x;
  }
};

int main() {
  std::priority_queue<int, std::vector<int>, std::greater<int>> Q;
  //默认大根
  //如果要小根堆，那么就要 greater<int>
  Q.push(5);
  Q.push(4);
  Q.push(7);
  Q.push(6);
  std::cout << Q.top() << '\n';
  Q.pop();
  std::cout << Q.top() << '\n';
}