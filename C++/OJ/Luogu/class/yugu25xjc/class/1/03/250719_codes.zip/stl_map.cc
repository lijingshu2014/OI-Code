#include <map>
#include <string>
#include <iostream>

struct A {
  int x;
  
  inline bool operator<(const A &o) const {
    return x > o.x;
  }
}; 

int main() {
  std::map<std::string, int> NOIP;
  std::map<int, std::string> re_NOIP;
  std::map<int, A> m;
  std::map<A, int> rm;
  NOIP["kkksc03"] = 1;
  re_NOIP[1] = "kkksc03";
  NOIP["chen_zhe"] = 5;
  re_NOIP[5] = "chen_zhe";
  NOIP["yifusuyi"] = 600;
  re_NOIP[600] = "yifusuyi";
  std::cout << NOIP["chen_zhe"] << '\n';
  std::cout << re_NOIP[600] << '\n';
}