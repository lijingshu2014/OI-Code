#include <list>
#include <iostream>

void printList(const std::list<int> Q) {
  for (auto i : Q) std::cout << i << ' ';
  std::cout << '\n';
}

int main() {
  std::list<int> Q;
  Q.push_back(1);
  Q.push_back(2);
  Q.push_back(3);
  printList(Q);
  Q.pop_back();
  printList(Q);
  Q.push_front(4);
  printList(Q);
  Q.push_front(5);
  Q.push_front(5);
  Q.pop_front();
  printList(Q);
  auto it = Q.begin();
  while (*it != 4) ++it;
  std::cout << *it << '\n';
  Q.insert(it, 7);
  printList(Q);
  it = Q.begin();
  while (*it != 4) ++it;
  Q.erase(it);
  printList(Q);
}