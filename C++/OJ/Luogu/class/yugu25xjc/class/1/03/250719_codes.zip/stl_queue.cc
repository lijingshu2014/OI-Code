#include <queue>
#include <iostream>

int main() {
  std::queue<int> Q;
  Q.push(3);
  Q.push(2);
  Q.push(1);
  std::cout << Q.front() << ' ' << Q.back() << '\n';
  Q.pop();
  std::cout << Q.front() << ' ' << Q.back() << '\n';
}