#include <string>
#include <iostream>

void println(const std::string &s) {
  std::cout << s << '\n';
}

int main() {
  std::string s = "abcdefg";
  println(s);
  std::cout << s.length() << '\n';
  s.clear();
  println(s);
  s = "ABC";
  s += "d";
  println(s);
  s += "d";
  s = s + "d";
  println(s);
  s = "ABC";
  s.insert(1, "OVO");
  println(s);
  s.insert(2, "XYZ");
  println(s);
  //s.replace(2, 4, "TWT");
  s.erase(2, 4);
  println(s);
  println(s.substr(1));
  s = "abcdefg";
  std::string t = "bcd";
  if (s.find(t) != std::string::npos) {
    std::cout << s.find(t)<< '\n';
  } else {
    std::cout << "Not Found" << '\n';
  }
}