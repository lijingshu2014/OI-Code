#include <utility>
#include <array>
#include <iostream>

int main() {
  std::pair<int, double> p1, p2;
  p1.first = 2;
  p1.second = 3.5;
 // std::cout << p.first << ' ' << p.second << '\n';
  p2 = std::make_pair(2, 0.5);
  if (p1 < p2) std::cout << "OvO\n";
  std::array<int, 3> t;
  t[2] = 1;
}