#include <bits/stdc++.h>

int main() {
  int n;
  std::cin >> n;
  std::vector<int> a;
  for (int i = 0; i < n; ++i) {
    int x;
    std::cin >> x;
    a.push_back(x);
  }
  a.pop_back();
  // for (int i = 0; i < n; ++i) std::cin >> a[i];
  std::cout << a.size() << '\n';
  a.insert(a.begin(), 0);
  a.erase(a.begin());
  for (int i = 0; i < a.size(); ++i) std::cout << a[i] << '\n';
  std::cout << a.front() << '\n';
  std::cout << a.back() << '\n';
  for (auto i : a) std::cout << i << '\n';
}