#include <vector>
#include <iostream>

int main() {
 /* std::stack<int> s;
  s.push(3);
  s.push(2);
  std::cout << s.top() << '\n';
  s.pop();
  std::cout << s.top() << '\n';
  while (!s.empty()) s.pop(); */
  std::vector<int> s;
  s.push_back(3);
  s.push_back(2);
  std::cout << s.back() << '\n';
  s.pop_back();
  std::cout << s.back() << '\n';
  std::cout << s[0] << '\n';
  s.push_back(2);
  s.push_back(2);
  s.push_back(2);
  std::cout << s[2] << '\n';
}