#include<bits/stdc++.h>
using namespace std;
const int maxn=200007;
const int mod=1e4;
const int J=18;
vector <int> e[maxn];
int fa[J+1][maxn],mx[J+1][maxn],mul[J+1][maxn];
int dep[maxn];
int a[maxn];
int n,q;
void dfs(int u)
{
    mx[0][u]=a[u];
    mul[0][u]=a[u]%mod;
    for(auto v:e[u])
    {
        if(v==fa[0][u]) continue;
        dep[v]=dep[u]+1;
        fa[0][v]=u;
        dfs(v);
    }
    return ;
}
void pre()
{
    for(int k=1;k<=J;k++)
        for(int i=1;i<=n;i++)
        {
            fa[k][i]=fa[k-1][fa[k-1][i]];
            mx[k][i]=max(mx[k-1][i],mx[k-1][fa[k-1][i]]);
            mul[k][i]=mul[k-1][i]*mul[k-1][fa[k-1][i]]%mod;
        }
    return ;
}
int query(int x)
{
    int pos=fa[0][x];//从x节点跳到pos之前不会被拦住
    int ans=1;
    for(int k=J;k>=0;k--)
    {//尝试多跳2^k步
        if(dep[pos]>=(1<<k)&&mx[k][pos]<a[x])
        {
            //从x跳到pos之前不会被拦住
            //从pos开始多跳2^k步都不会被拦住
            //-> 从x跳到 (pos再往上2^k步的地方) 之前都不会被拦住
            pos=fa[k][pos];
        }
    }
    //[x,pos)
    int d=dep[x]-dep[pos];
    for(int k=J;k>=0;k--)
    {
        if(d&(1<<k))
            ans=ans*mul[k][x]%mod,x=fa[k][x];
    }
    return ans;
}
int main()
{
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    int u,v;
    for(int i=1;i<n;i++)
    {
        scanf("%d%d",&u,&v);
        e[u].push_back(v);
        e[v].push_back(u);
    }
    dep[1]=1;
    dfs(1);
    pre();
    while(q--)
    {
        scanf("%d",&u);
        printf("%d\n",query(u));
    }
    return 0;
}