#include<bits/stdc++.h>
using namespace std;
const int maxn=500007;
int a[maxn];
int n;
long long ans;
int main()
{
    
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    for(int k=0;k<=20;k++)
    {
        int lst=0;//lst表示[1,i]内最后一个第k位为1的数字下标
        
        for(int i=1;i<=n;i++)//i作为右端点
        {
            if((a[i]>>k)&1)//左端点<=lst时区间或在2^k这一位为1
                lst=i;
            ans+=(1ll<<k)*lst;//有效的左端点[1,lst]
            //有lst个区间答案里包括2^k
        }
    }
    printf("%lld\n",ans);
    return 0;
}