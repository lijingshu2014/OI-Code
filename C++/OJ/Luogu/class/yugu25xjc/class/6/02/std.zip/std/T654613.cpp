#include<iostream>
#include<vector>
using namespace std;
const int MAXN=1e2+20;
vector<int> e[MAXN];
int n,k;
int l,m;
int a[MAXN],ans;
bool dfs(int u){
	if(a[u]){
		a[u]--;
		return 1;
	}
	if(e[u].empty())
		return 0;
	for(auto v:e[u])
		if(!dfs(v))
			return 0;
	return 1;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	cin>>k;
	while(k--){
		cin>>l>>m;
		while(m--){
			int u;
			cin>>u;
			e[l].push_back(u);
		}
	}
	ans=a[n],a[n]=0;
	while(dfs(n))
		ans++;
	cout<<ans;
	return 0;
}