#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int ans;
bool check(int mid){
	int m=0;
	int last=-1e9;
	for(int i=0;i<n;i++){
		if(s[i]=='1'&&i-last<mid) return 0;//放前就不满足条件
		if(s[i]=='1'){
			last=i;
		}
	}
	last=-1e9;//上一个
	for(int i=0;i<n;i++){
		if(s[i]=='1'&&i-last<mid) m--;//不满足条件
		if((i-last>=mid)&&s[i]!='1'){//可放
			last=i;
			m++;//计数器++
		}
		if(s[i]=='1') last=i;
	}
	return m>=2;
}
int main(){
	cin>>n>>s;
	int l=1,r=1e5+10;
	while(l<=r){//二分
		int mid=(l+r)/2;
		if(check(mid)){
			ans=mid;
			l=mid+1;
		}else{
			r=mid-1;
		}
	}
	cout<<ans;
    return 0;
}