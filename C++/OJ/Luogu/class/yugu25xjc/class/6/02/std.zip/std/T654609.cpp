#include<bits/stdc++.h>
using namespace std;
const int mod=1e4;
const int maxn=200007;
const int J=17;
int mul[J+1][maxn],mx[J+1][maxn];
int n,q;
int a[maxn];
void pre()
{
    for(int i=1;i<=n;i++)
        mx[0][i]=a[i],mul[0][i]=a[i]%mod;
    for(int k=1;k<=J;k++)
        for(int i=1;i+(1<<k)-1<=n;i++)
        {
            mx[k][i]=max(mx[k-1][i],mx[k-1][i+(1<<(k-1))]);
            mul[k][i]=mul[k-1][i]*mul[k-1][i+(1<<(k-1))]%mod;
        }
}
int main()
{
    scanf("%d%d",&n,&q);
    for(int i=1;i<=n;i++)
        scanf("%d",&a[i]);
    pre();
    int x;
    while(q--)
    {
        scanf("%d",&x);
        int pos=x+1;
        int ans=1;//已经确认不会被[x,pos-1]拦住
        for(int k=J;k>=0;k--)
        {
            if(pos+(1<<k)-1<=n&&mx[k][pos]<a[x])//[pos,pos+(2^k)-1]<a[x]
            //[x,pos-1]不会拦住
            //[pos,pos+(2^k)-1]不会拦住
            //-> [x,pos+(2^k)-1] 不会拦住
            {
                // ans=ans*mul[k][pos]%mod;
                pos+=(1<<k);
            }
        }
        int d=pos-x;//从x往后d座山的乘积
        for(int k=J;k>=0;k--)
        if(d&(1<<k)) ans=ans*mul[k][x]%mod,x+=(1<<k);
        printf("%d\n",ans);
    }
    return 0;
}