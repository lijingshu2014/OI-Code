#include <bits/stdc++.h>

using namespace std;

const int N = 100 + 5;

int n;
long long a[N + N], f[N * 2][N * 2];

int main() {
    cin >> n;
    for (int i = 1; i <= n; i ++)
        cin >> a[i], a[i + n] = a[i];
    for (int len = 2; len <= n; len ++) 
        for (int l = 1; l + len - 1 <= n * 2; l ++) {
            int r = l + len - 1;
            for (int k = l; k < r; k ++)
                f[l][r] = max (f[l][r], f[l][k] + f[k + 1][r] +
                    a[l] * a[k + 1] * a[r + 1]);
        }
    long long ans = 0;
    for (int i = 1; i <= n; i ++)
        ans = max (ans, f[i][i + n - 1]);
    cout << ans << '\n';
    return 0;
}