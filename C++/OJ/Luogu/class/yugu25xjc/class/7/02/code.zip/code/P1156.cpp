#include <bits/stdc++.h>

using namespace std;

int D, G;
int dp[105];
struct Rubbish {
    int T, F, H;
} rubbish[105];

inline bool operator < (Rubbish a, Rubbish b) {
    return a.T < b.T;
}

int main() {
    cin >> D >> G;
    for (int i = 1; i <= G; i ++) {
        cin >> rubbish[i].T >> rubbish[i].F >> rubbish[i].H;
    }
    sort (rubbish + 1, rubbish + 1 + G);
    dp[0] = 10;
    for (int i = 1; i <= G; i ++) {
        for (int j = D; j >= 0; j --)
            if (dp[j] >= rubbish[i].T) {
                if (j + rubbish[i].H >= D) {
                    cout << rubbish[i].T << '\n';
                    return 0;
                }
                dp[j + rubbish[i].H] = max(dp[j + rubbish[i].H], dp[j]);
                dp[j] += rubbish[i].F;
            }
    }
    cout << dp[0] << '\n';
    return 0;
}