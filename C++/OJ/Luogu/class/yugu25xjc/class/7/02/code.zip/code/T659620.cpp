#include <bits/stdc++.h>

using namespace std;

const int N = 1e6 + 5;

int n;
int a[N];
long long pre[N], suf[N];

int main() {
    cin >> n;
    for (int i = 1; i <= n; i ++) 
        cin >> a[i];
    
    long long sum = 0;

    for (int i = 1; i <= n; i ++) {
        if (sum < 0) sum = 0;
        sum += a[i];
        pre[i] = sum;
    }

    sum = 0;
    for (int i = n; i >= 1; i --) {
        if (sum < 0) sum = 0;
        sum += a[i];
        suf[i] = sum;
    }

    for (int i = 2; i <= n; i ++) {
        pre[i] = max (pre[i], pre[i - 1]);
    }

    for (int i = n - 1; i >= 1; i --) {
        suf[i] = max (suf[i], suf[i + 1]);
    }

    long long ans = -1e18;
    for (int i = 2; i <= n - 1; i ++) {
        ans = max(ans, pre[i - 1] + suf[i + 1]);
    }

    cout << ans << endl;
    return 0;
}