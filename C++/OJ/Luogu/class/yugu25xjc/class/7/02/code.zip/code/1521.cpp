#include <bits/stdc++.h>

using namespace std;

const int N = 100 + 5;

int n, k;
int f[N][N * N];

int main() {
    ios :: sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    cin >> n >> k;
    f[0][0] = 1;
    // for (int i = 1; i <= n; i ++)
    //     for (int j = 0; j <= i * (i - 1) / 2; j ++) {
    //         for (int k = j - i + 1; k <= j; k ++)
    //             f[i][j] = (f[i][j] + f[i - 1][k]) % 10000;
    //     }
    for (int i = 1; i <= n; i ++) {
        static int sum[N * N];
        sum[0] = f[i - 1][0];
        for (int j = 1; j <= i * (i - 1) / 2; j ++)
            sum[j] = (sum[j - 1] + f[i - 1][j]) % 10000;
        for (int j = 0; j <= i * (i - 1) / 2; j ++) {
            f[i][j] = (sum[j] - (j - i >= 0 ? sum[j - i] : 0) + 10000) % 10000;
        }
    }
    cout << f[n][k] << endl;
    return 0;
}