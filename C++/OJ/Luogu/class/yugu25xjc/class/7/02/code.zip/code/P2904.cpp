#include <bits/stdc++.h>

using namespace std;

const int N = 2500 + 5;

int n, m, w[N], f[N];

int main() {
    memset (f, 0x3f, sizeof (f));
    cin >> n >> m;
    w[0] = 2 * m;
    for (int i = 1; i <= n; i ++) {
        int x;
        cin >> x;
        w[i] = w[i - 1] + x;
    }
    f[0] = 0;
    for (int i = 1; i <= n; i ++)
        for (int j = 1; j <= i; j ++)
            f[i] = min (f[i], f[i - j] + w[j]);
    cout << f[n] - m << endl;
    return 0;
}