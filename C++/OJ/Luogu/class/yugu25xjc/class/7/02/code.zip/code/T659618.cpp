#include <bits/stdc++.h>

using namespace std;

int main() {
    string s;
    int s1 = 0, s2 = 0;
    cin >> s;
    for (int i = 0; i < (int) s.size(); i ++) {
        if (i % 2 == 0) {
            if (s[i] == 'b') s1 ++;
            else s2 ++;
        }
        else {
            if (s[i] == 'a') s1 ++;
            else s2 ++;
        }
    }

    cout << min (s1, s2) << endl;
    return 0;
}