#include <bits/stdc++.h>

using namespace std;

int main() {
    int k;
    cin >> k;
    double S = 0;

    for (int i = 1; ;i ++) {
        S += 1.0 / i;
        if (S > k) {
            cout << i << endl;
            return 0;
        }
    }

    return 0;
}