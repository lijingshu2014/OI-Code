#include <bits/stdc++.h>

using namespace std;

int m, n;
int ids[105][1005], cnt[105];
int a[1005],b[1005],c[1005];
long long dp[105][1005];

int main() {
    cin >> m >> n;
    for (int i = 1; i <= n; i ++) {
        cin >> a[i] >> b[i] >> c[i];
        ids[c[i]][++ cnt[c[i]]] = i;
    }
    for (int i = 1; i <= 100; i ++) {
        for (int j = 0; j <= m; j ++) {
            dp[i][j] = dp[i - 1][j];
        }
        for (int j = 1; j <= cnt[i]; j ++) {
            int id = ids[i][j];
            for (int k = a[id]; k <= m; k ++) {
                dp[i][k] = max (dp[i][k], dp[i - 1][k - a[id]] + b[id]);
            }
        }
    }

    cout << dp[100][m] << endl;
    return 0;
}