#include <bits/stdc++.h>

using namespace std;

int n;
long long dp[1005];
int vis[1005];
vector<int> pri;

int main() {
    cin >> n;
    for (int i = 2; i <= n; i ++) {
        if (!vis[i]) {
            pri.push_back(i);
        }
        for (int j = i + i; j <= n; j += i) {
            vis[j] = 1;
        }
    }
    dp[0] = 1;
    for (int p : pri) {
        for (int i = p; i <= n; i ++) {
            dp[i] += dp[i - p];
        }
    }
    cout << dp[n] << endl;
    return 0;
}