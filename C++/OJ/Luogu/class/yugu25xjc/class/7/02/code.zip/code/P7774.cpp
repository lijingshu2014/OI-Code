#include <bits/stdc++.h>

using namespace std;

int n, m;
int a[15], b[15];
int f[15][365];

int main() {
    cin >> n >> m;
    for (int i = 1; i <= n; i ++) cin >> a[i];
    for (int i = 1; i <= m; i ++) cin >> b[i];

    f[0][0] = 1;
    for (int i = 1; i <= n; i ++) {
        for (int j = 0; j <= 359; j ++) 
            for (int k = 0; k < 359; k ++) {
            f[i][j] |= f[i - 1][(j - a[i] * k % 360 + 360) % 360];
            f[i][j] |= f[i - 1][(j + a[i] * k % 360 + 360) % 360];
        }
    }
    
    for (int i = 1; i <= m; i ++) 
        if (f[n][b[i]])
            cout << "YES" << endl;
        else
            cout << "NO" << endl;
    return 0;
}