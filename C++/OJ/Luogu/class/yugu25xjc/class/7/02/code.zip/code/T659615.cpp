#include <bits/stdc++.h>

using namespace std;

int n;
long long f[45][2];

int main() {
    cin >> n;
    f[0][0] = 1;
    for (int i = 1; i <= n; i ++) {
        f[i][0] = f[i - 1][0];
        if (i >= 2) f[i][0] += f[i - 2][0];

        f[i][1] += f[i - 1][1];
        if (i >= 2) f[i][1] += f[i - 2][1];
        if (i >= 3) f[i][1] += f[i - 3][0];
    }
    cout << f[n][0] + f[n][1] << endl;
    return 0;
}