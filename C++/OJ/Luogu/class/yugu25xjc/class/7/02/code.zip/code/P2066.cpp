#include <bits/stdc++.h>

using namespace std;

int n, m;
int f[20][20], way[20];
int a[20][20];

int main() {
    cin >> n >> m;
    f[0][0] = 0;
    for (int i = 1; i <= n; i ++) 
        for (int j = 1; j <= m; j ++) 
            cin >> a[i][j];

    for (int i = 1; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            for (int k = 0; k <= j; k++) {
                f[i][j] = max(f[i][j], f[i - 1][j - k] + a[i][k]);
            }
        }
    }
    
    cout << f[n][m] << '\n';
    
    for (int i = n, j = m; i; i--) {
        for (int k = 0; k <= j; k++) {
            if (f[i][j] == f[i - 1][j - k] + a[i][k]) {
                way[i] = k;
            }
        }
        j -= way[i];
    }
    
    for (int i = 1; i <= n; i++) cout << i << ' ' << way[i] << '\n';
    return 0;
}